<!DOCTYPE html>
<html lang="zxx">

<head>


    <meta charset="UTF-8">
    <meta name="description" content="Freight-Broker Template">
    <meta name="keywords" content="Freight-Broker, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' >
    <meta property="og:locale" content="en_US" />
	<meta property="og:type" content="website" />
	<meta property="og:title" content="Fracktech: Top-Notch Web Development Company" />
	<meta property="og:description" content="Fracktech is a web development company that designs and develops stunning web applications and responsive content for all types businesses." />
	<meta property="og:url" content="https://fracktechnologies.com/" />
	<meta property="og:site_name" content="Fracktech" />
	<meta property="article:modified_time" content="2021-07-12T07:37:07+00:00" />
    <title>Paramount-Dispatch | TermsConditions</title>
    <style>
        .gold{
            color : #d0ae66 !important;
        }
        .bg-gold{
            background : #d0ae66 !important;
        }
    </style>

    <link href="./sources/fontsgoogle.css" rel="stylesheet">
    <link href="./sources/fontsgoogle2.css" rel="stylesheet">

    <link rel="stylesheet" href="./sources/bootstrap.css" type="text/css" />
    <!---->
    <link rel='stylesheet' id='wpacu-combined-css-head-1' href='./sources/head-e5.css' type='text/css' media='all' />

    <link rel='stylesheet' id='google-fonts-1-css' href='./sources/gooleaps.css' type='text/css' media='all' />

</head>
    <div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
        <div class="offcanvas__search__option">
            <span class="icon_search search-switch"></span>
        </div>
        <div class="offcanvas__logo">
            <a href="./index.php">
                <img src="img/xfooter-logo.png.pagespeed.ic.QfQCJiQvaR.webp" alt="">
            </a>
        </div>
        <div id="mobile-menu-wrap"></div>
        <ul class="offcanvas__widget">
            <li><span class="icon_phone"></span> +1-516-246-6566</li>
            <li><span class="icon_pin"></span> 978 Hempstead Tpke, Franklin Sq, NY, US</li>
        </ul>
        <div class="offcanvas__auth">
            <a href="#"><span class="icon_profile"></span> Register or Sign in</a>
        </div>
        <div class="offcanvas__social">
            <a href="#"><span class="social_facebook"></span></a>
            <a href="#"><span class="social_twitter"></span></a>
            <a href="#"><span class="social_linkedin"></span></a>
            <a href="#"><span class="social_pinterest"></span></a>
        </div>
    </div>

<header class="header">
    <div class="header__top">
        <div class="container">
            <div class="row">
                <div class="col-lg-9 offset-lg-3">
                    <ul class="header__top__widget">
                        <li><span class="icon_phone"></span> +1-516-246-6566</li>
                        <li><span class="icon_pin"></span> 978 Hempstead Tpke, Franklin Sq, NY, US</li>
                    </ul>
                    <div class="header__top__right">
                        <div class="header__top__right__auth">
                            <a href="#"><span class="icon_profile"></span> Register or Sign in</a>
                        </div>
                        <div class="header__top__right__social">
                            <a href="#"><span class="social_facebook"></span></a>
                            <a href="#"><span class="social_twitter"></span></a>
                            <a href="#"><span class="social_linkedin"></span></a>
                            <a href="#"><span class="social_pinterest"></span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header__options">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="header__logo">
                        <a href="./index.php"><img src="img/new_logo.png" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-8">
                        <nav class="header__menu mobile-menu">
                            <ul>
                                <li><a href="./index.php">Home</a></li>
                                <li><a href="./services.php">Services</a> </li>
                                <li><a href="./about.php">About</a></li>

                                <li><a href="./Pricing.php">Pricing</a></li>
                                <li><a href="./Carrier.php">Carrier-Setup</a></li>
                                <li><a href="./Faq.php">FAQs</a></li>

                                <li><a href="./contact.php">Contacts</a></li>
                            </ul>
                        </nav>
                </div>
                    

            </div>
        </div>
        <div class="canvas__open"><i class="fa fa-bars"></i></div>
    </div>
</header>

<div id="content" class="site-content ">
    <div data-elementor-type="wp-page" data-elementor-id="2110" class="elementor elementor-2110"
        data-elementor-settings="[]">
        <div class="elementor-section-wrap">
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-2391500 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                data-id="2391500" data-element_type="section">
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-36a7ff2"
                        data-id="36a7ff2" data-element_type="column">
                        <div class="elementor-widget-wrap elementor-element-populated">
                            <div class="elementor-element elementor-element-84b91de elementor-widget elementor-widget-heading"
                                data-id="84b91de" data-element_type="widget" data-widget_type="heading.default">
                                <div class="elementor-widget-container">
                                    <h2 class="elementor-heading-title elementor-size-default"><b>Terms & Conditions</b>
                                    </h2>
                                </div>
                            </div>
                            <div class="elementor-element elementor-element-67d979e elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                                data-id="67d979e" data-element_type="widget" data-widget_type="divider.default">
                                <div class="elementor-widget-container">
                                    <div class="elementor-divider">
                                        <span class="elementor-divider-separator">
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="elementor-element elementor-element-65551ba elementor-widget elementor-widget-text-editor"
                                data-id="65551ba" data-element_type="widget" data-widget_type="text-editor.default">
                                <div class="elementor-widget-container">
                                    <ul>
                                        <li><strong>CUSTOMER AUTHORIZATION.</strong> Customer authorizes States Dispatch
                                            Services to arrange for
                                            motor carriers, forwarders, customs brokers, shipping agents, warehousemen
                                            and others (“service providers”),
                                            as required, to receive, transport, store, assemble, consolidate, break-bulk
                                            and deliver the goods. Unless
                                            Customer instructs States Dispatch Services, in writing, prior to shipment
                                            to use a specific service provider,
                                            States Dispatch Services may utilize any available service provider.
                                            Customer is defined as any person or
                                            entity that requests services from States Dispatch Services whether for its
                                            own account or on behalf of
                                            others, or any person or entity to whom States Dispatch Services has
                                            extended
                                            credit.</li>
                                        <li><strong>INDEPENDENT CONTRACTORS.</strong> All service providers,
                                            including but not limited to motor carriers, drayage carriers, rail
                                            carriers, warehousemen,
                                            are independent contractors, unless required to act as the agent of Customer
                                            for U.S. Customs purposes.
                                            Customer’s goods shall be tendered to such service providers subject to
                                            their rules, tariffs and terms
                                            and conditions. States Dispatch Services will supply or direct Customer to
                                            Service Providers’
                                            specific rules, tariffs, and terms and conditions upon Customer’s written
                                            request.</li>
                                        <li><strong>QUOTATIONS. </strong>Quotations as to fees, rates of duty, freight
                                            charges,
                                            insurance premiums or other charges given by States Dispatch Services to the
                                            Customer are for
                                            informational purposes only and are subject to change without notice and
                                            shall not under any
                                            circumstances be binding upon States Dispatch Services unless States
                                            Dispatch Services in writing
                                            specifically undertakes the handling or transportation of the shipment at a
                                            specific
                                            rate.</li>
                                        <li><strong>CUSTOMER’S DUTY.</strong> Customer warrants the accuracy of shipment
                                            descriptions,
                                            weights, dimensions, written vehicle sanitary or temperature requirements,
                                            invoices, documents and
                                            other information furnished to States Dispatch Services by the Customer or
                                            its agent for export,
                                            entry or other purposes and the Customer agrees to indemnify and hold
                                            harmless States Dispatch
                                            Services against any increased rates, charges, duty, penalty, fine or
                                            expense including attorneys’
                                            fees, resulting from inaccurate, incomplete statement, omission or any
                                            failure to make timely
                                            presentation, even if not due to any negligence of the Customer. It is the
                                            responsibility of the
                                            Customer to know and comply with the marking requirements of the U.S.
                                            Customs Service, the regulations
                                            of the U.S. Food and Drug Administration and all other requirements,
                                            including regulations of Federal,
                                            state and/or local agencies pertaining to the merchandise. It is understood
                                            and agreed that Customer bears
                                            all responsibilities of the “Shipper” and/or “Loader” under the FDA Sanitary
                                            Food Transportation regulations,
                                            and must provide specific written requirements as to vehicle sanitary
                                            requirements and/or temperature requirements
                                            to States Dispatch Services prior to shipment and to the motor carrier at
                                            the time of physical tender. Customer
                                            shall be responsible for assessing vehicle cleanliness and/or trailer
                                            temperature at pick-up. States Dispatch
                                            Services shall not be responsible for action taken or fines or penalties
                                            assessed by any governmental agency
                                            because of the failure of the Customer to comply with the law or the
                                            requirements or regulations of any
                                            governmental agency or with a notification issued to the Customer by any
                                            such agency.<p>Shipper provided
                                                and applied Cargo Security Seals may be used at time of loading of Full
                                                Truck Load shipments only.
                                                When Cargo Security Seals are applied by Shipper, “Shipper Load and
                                                Count” will prevail. LTL
                                                shipments are not required to have a Security Seal or Continuous
                                                Security Seal Record due to the
                                                inherent nature of LTL shipments. </p>
                                        </li>
                                    </ul>
                                    <ul>
                                        <li><strong>INDEMNIFICATION. </strong>In the
                                            event that a carrier, other person or any governmental agency makes a claim
                                            or institutes legal
                                            action against States Dispatch Services for ocean or other freight, duties,
                                            fines, penalties,
                                            liquidated damages or other money due rising from a shipment of goods of the
                                            Customer, the
                                            Customer agrees to defend, indemnify and hold harmless States Dispatch
                                            Services for any amount
                                            States Dispatch Services may be required to pay such carrier, other person
                                            or governmental
                                            agency together with reasonable expenses, including attorneys’ fees,
                                            incurred by States
                                            Dispatch Services in connection with defending such claim or legal action
                                            and obtaining
                                            reimbursement from the Customer. The confiscation or detention of the goods
                                            by any
                                            governmental authority shall not affect or diminish the liability of the
                                            Customer to
                                            States Dispatch Services to pay all charges or other money due promptly on
                                            demand.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>

</div><!-- #content -->

<footer class="footer bg-gold">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="footer__about">
                    <div class="footer__logo">
                        <a href="./index.php"><img src="./img/new_logo.png" alt=""></a>
                    </div>
                    <p>We’re a professional freight dispatching company with proven experience in the field.
                         Our team helps you get the most profitable loads to deliver. We generate high quality 
                         and converting leads, providing you all the documents. Making business efficient for both parties.
                    </p>
                    <div class="footer__social">
                        <a href="#"><span class="social_facebook"></span></a>
                        <a href="#"><span class="social_twitter"></span></a>
                        <a href="#"><span class="social_linkedin"></span></a>
                        <a href="#"><span class="social_pinterest"></span></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 offset-lg-1 col-md-6 col-sm-6">
                <div class="footer__widget">
                    <h5>Quick links</h5>
                    <ul>
                                <li><a href="./about.php">History</a></li>
                                <li><a href="./Dry-van.php">DRY VAN DISPATCH SERVICE</a></li>
                                <li><a href="./Owner-operator.php">OWNER OPERATOR SERVICE</a></li>
                                <li><a href="./Power-only.php">POWER ONLY DISPATCH SERVICE</a></li>
                                <li><a href="./Reefer.php">REEFER DISPATCH SERVICE</a></li>
                                <li><a href="./conditions.php">Terms & Conditions</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
                <div class="footer__widget">
                    <h5>Contacts</h5>
                    <ul class="address">
                        <li><span class="icon_pin"></span><a href="https://goo.gl/maps/Xs7t8fcVACHGszMh8" >978 Hempstead Tpke,Franklin Sq,US</a></li>
                        <li><span class="icon_phone" ></span><a href="tel:5554280940"> +1-516-246-6566</a></li>
                        <li><span class="icon_mail"></span> <a href="mailto:Info@paramountservices.com"
                                class="__cf_email__"
                                data-cfemail="b3daddd5dc9dd0dcdfdcdfdad1f3d4ded2dadf9dd0dcde">Info@paramountservices.com</a>
                        </li>
                    </ul>
                    
                    
                </div>
            </div>
        </div>
    </div>
    <div class="footer__copyright">
        <div class="container">
            <div class="row">
                <div class="col-lg-9 col-md-8">
                    <div class="footer__copyright__text">

                        <p>Copyright &copy;
                            <script data-cfasync="false"
                                src="#"></script>
                            <script>document.write(new Date().getFullYear());</script> All rights reserved
                        </p>
                    </div>
                </div>
                <!----
                <div class="col-lg-3 col-md-4">
                    <div class="footer__copyright__links">
                        <a href="#">Client Login</a>
                        <a href="#">Join Team</a>
                    </div>
                </div>-->
            </div>
        </div>
    </div>
</footer>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="./sources/jquery.js"></script>
    <script>eval(mod_pagespeed_EJfk9gGSrQ);</script>
    <script>eval(mod_pagespeed_vadjZYzCTr);</script>
    <script>eval(mod_pagespeed_QwdlkBSDSA);</script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

    <script async src="./sources/tagmanager.js"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');
    </script>
    <script defer src="./sources/cloudflare.js"
        ></script>

</body>

</html>