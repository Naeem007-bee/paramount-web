<!DOCTYPE html>
<html lang="zxx">

<head>
    <style>
        .gold{
            color : #d0ae66 !important;
        }
        .bg-gold{
            background : #d0ae66 !important;
        }
    </style>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <meta charset="UTF-8">
    <meta name="description" content="Freight-Broker Template">
    <meta name="keywords" content="Freight-Broker, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1'>
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Fracktech: Top-Notch Web Development Company" />
    <meta property="og:description"
        content="Fracktech is a web development company that designs and develops stunning web applications and responsive content for all types businesses." />
    <meta property="og:url" content="https://fracktechnologies.com/" />
    <meta property="og:site_name" content="Fracktech" />
    <meta property="article:modified_time" content="2021-07-12T07:37:07+00:00" />
    <title>Paramount-Dispatch | Home</title>
    <!---->
    <link href="./sources/fontsgoogle.css" rel="stylesheet">
    <link href="./sources/fontsgoogle2.css" rel="stylesheet">

    <link rel="stylesheet" href="./sources/bootstrap.css" type="text/css" />

    <link rel='stylesheet' id='google-fonts-1-css' href='./sources/gooleaps.css' type='text/css' media='all' />

    <link rel='stylesheet' id='wpacu-combined-css-head-1'
        href='./sources/head-df80cafcf501f63fb9c6384614be08d3e5110d4a.css' type='text/css' media='all' />

</head>

<body
    class="page-template page-template-elementor_header_footer page page-id-554 layout-fullwidth blog-default jet-desktop-menu-active elementor-default elementor-template-full-width elementor-kit-15 elementor-page elementor-page-554">


    <div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
        <div class="offcanvas__search__option">
            <span class="icon_search search-switch"></span>
        </div>
        <div class="offcanvas__logo">
            <a href="./index.php">
                <img src="img/xfooter-logo.png.pagespeed.ic.QfQCJiQvaR.webp" alt="">
            </a>
        </div>
        <div id="mobile-menu-wrap"></div>
        <ul class="offcanvas__widget">
            <li><span class="icon_phone"></span> +1-516-246-6566</li>
            <li><span class="icon_pin"></span> 978 Hempstead Tpke, Franklin Sq, NY, US</li>
        </ul>
        <div class="offcanvas__auth">
            <a href="#"><span class="icon_profile"></span> Register or Sign in</a>
        </div>
        <div class="offcanvas__social">
            <a href="#"><span class="social_facebook"></span></a>
            <a href="#"><span class="social_twitter"></span></a>
            <a href="#"><span class="social_linkedin"></span></a>
            <a href="#"><span class="social_pinterest"></span></a>
        </div>
    </div>


    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 offset-lg-3">
                        <ul class="header__top__widget">
                            <li><span class="icon_phone"></span> +1-516-246-6566</li>
                            <li><span class="icon_pin"></span> 978 Hempstead Tpke, Franklin Sq, NY, US</li>
                        </ul>
                        <div class="header__top__right">
                            <div class="header__top__right__auth">
                                <a href="#"><span class="icon_profile"></span> Register or Sign in</a>
                            </div>
                            <div class="header__top__right__social">
                                <a href="#"><span class="social_facebook"></span></a>
                                <a href="#"><span class="social_twitter"></span></a>
                                <a href="#"><span class="social_linkedin"></span></a>
                                <a href="#"><span class="social_pinterest"></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header__options">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="header__logo">
                            <a href="./index.php"><img src="img/new_logo.png" alt=""></a>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <nav class="header__menu mobile-menu">
                            <ul>
                                <li class="active"><a href="./index.php">Home</a></li>
                                <li><a href="./services.php">Services</a> </li>
                                <li><a href="./about.php">About</a></li>

                                <li><a href="./Pricing.php">Pricing</a></li>
                                <li><a href="./Carrier.php">Carrier-Setup</a></li>
                                <li><a href="./Faq.php">FAQs</a></li>

                                <li><a href="./contact.php">Contacts</a></li>
                            </ul>
                        </nav>
                    </div>
                    
                </div>
            </div>
            <div class="canvas__open"><i class="fa fa-bars"></i></div>
        </div>
    </header>

    <!--background-color: rgba(0,0,0,.5); display: inline;-->
    <section class="hero spad set-bg" data-setbg="img/slider.jpeg">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="hero__text">
                        <h3 class="elementor-heading-title elementor-size-default"
                            style="color: #E7E9EB;background-color: rgba(0, 0, 0, 0.562); display: inline; ">Truck dispatch
                            services you need!<br><br></h2>
                            <h2 class="elementor-heading-title elementor-size-default gold"
                                style="color: #ffc800; background-color: rgba(0, 0, 0, 0.562); display: inline;">
                                Paramount dispatch services<br><br></h1>
                                <h4 class="elementor-heading-title elementor-size-default"
                                    style="color: #E7E9EB; background-color: rgba(0, 0, 0, 0.562); display: inline;">High
                                    quality dispatch loads
                                    services for every budget<br><br><br>
                        </h3>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="services spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 p-0">
                    <div class="section-title">
                        <span class="gold">What We do?</span>
                        <h2>Welcome to the Paramount Dispatch we are the best.</h2><br><br>
                    </div>
                </div>
                <div class="col-lg-5 offset-lg-2 p-0">
                    <div class="services__top__text">
                        <p><br>We Are A Complete Dispatch Service Company That Handles Finding, Booking And Negotiating.
                            Loads For Independent Truckers And Small Business. </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 p-0 order-lg-1">
                    <div class="services__item__pic set-bg" data-setbg="img/services/Service_1.jpeg"></div>
                </div>
                <div class="col-lg-3 p-0 order-lg-2">
                    <div class="services__item__text">
                        <div class="services__item__icon">
                            <img src="#" alt="">
                        </div>
                        <h5 class="gold">Dry Van Dispatch Service</h5>
                        <p>Paramount dispatch services offers Dry van services. Heavy machinery & any equipment? Dry van
                            is your answer.</p>
                        <a href="./Dry-van.php">Read More</a>
                    </div>
                </div>
                <div class="col-lg-3 p-0 order-lg-3">
                    <div class="services__item__pic set-bg" data-setbg="img/services/owner.jpeg"></div>
                </div>
                <div class="col-lg-3 p-0 order-lg-4">
                    <div class="services__item__text">
                        <div class="services__item__icon">
                            <img src="#" alt="">
                        </div>
                        <h5 class="gold">Owner Operator Service</h5>
                        <p>Owner-operaotor have their own equipment and trucks, and may drive their own trucks or hire
                            them out.</p>
                        <a href="./Owner-operator.php">Read More</a>
                    </div>
                </div>

            </div>
        </div>
    </section>



    <section class="chooseus spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="chooseus__text">
                        <div class="section-title gold">
                            <span class="gold">Our Benefit</span>
                            <h2>Why People Choose Us?</h2>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="chooseus__item">
                                    <div class="chooseus__item__icon">
                                        <img src="img/chooseus/xci-3.png.pagespeed.ic.XA8Lr9wN0Q.webp" alt="">
                                    </div>
                                    <div class="chooseus__item__text">
                                        <h5>Experience</h5>
                                        <p>With years of experience handling & managing dispatch services, we have
                                            proven ourselves as a professional in the industry.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="chooseus__item">
                                    <div class="chooseus__item__icon">
                                        <img src="img/chooseus/xci-1.png.pagespeed.ic.eXfk6xEhqR.webp" alt="">
                                    </div>
                                    <div class="chooseus__item__text">
                                        <h5>Quality Dispatch</h5>
                                        <p>By providing quality dispatch loads & friendly support, handling the hassle
                                            all by ourselves, all that with pricing that’s fit for every budget.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="chooseus__item">
                                    <div class="chooseus__item__icon">
                                        <img src="img/chooseus/xci-2.png.pagespeed.ic.yjtio_xhjE.webp" alt="">
                                    </div>
                                    <div class="chooseus__item__text">
                                        <h5>Custormer's Trust</h5>
                                        <p>Our experience speaks for itself, and we’ve gained our customers’ trust.</p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="chooseus__pic set-bg" data-setbg="img/chooseus/Choose.jpg"></div>
        </div>
        <!--<div class="chooseus__pic set-bg" data-setbg="img/chooseus/Choose.jpg"></div>-->
        </div>
    </section>
    <div data-elementor-type="wp-page" data-elementor-id="554" class="elementor elementor-554"
            data-elementor-settings="[]">
            <div class="elementor-section-wrap">

                <section
                    class="elementor-section elementor-top-section elementor-element elementor-element-5ed062b1 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="5ed062b1" data-element_type="section"
                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;}" style="margin:0 0">
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-25b78d43"
                            data-id="25b78d43" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-fed0364 elementor-widget elementor-widget-jet-headline"
                                    data-id="fed0364" data-element_type="widget"
                                    data-widget_type="jet-headline.default">
                                    <div class="elementor-widget-container">
                                        <span class="jet-headline jet-headline--direction-horizontal"><span
                                                class="jet-headline__part jet-headline__first"><span
                                                    class="jet-headline__label">What makes us</span></span><span
                                                class="jet-headline__space">&nbsp;</span><span
                                                class="jet-headline__part jet-headline__second"><span
                                                    class="jet-headline__label gold">different</span></span></span>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-4b2e0a0b elementor-widget-divider--view-line elementor-widget elementor-widget-divider gold"
                                    data-id="4b2e0a0b" data-element_type="widget" data-widget_type="divider.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-divider">
                                            <span class="elementor-divider-separator">
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <section
                                    class="elementor-section elementor-inner-section elementor-element elementor-element-8f551e7 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                    data-id="8f551e7" data-element_type="section">
                                    <div class="elementor-container elementor-column-gap-default">
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-77c3d493"
                                            data-id="77c3d493" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-2f358754 elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="2f358754" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>You're the boss</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-1d440b1f"
                                            data-id="1d440b1f" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-69562f50 elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="69562f50" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>No forced dispatch</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-33e0df5f"
                                            data-id="33e0df5f" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-f8a567d elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="f8a567d" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>Pay load = 100% yours</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                <section
                                    class="elementor-section elementor-inner-section elementor-element elementor-element-328ab7eb elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                    data-id="328ab7eb" data-element_type="section">
                                    <div class="elementor-container elementor-column-gap-default">
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-a251632"
                                            data-id="a251632" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-d852dc7 elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="d852dc7" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>We negotiate top paying rates</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-53e13b86"
                                            data-id="53e13b86" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-a7805b5 elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="a7805b5" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>Setup paperwork</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-797d7a30"
                                            data-id="797d7a30" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-98a19a4 elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="98a19a4" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>Fax/email documents</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                <section
                                    class="elementor-section elementor-inner-section elementor-element elementor-element-2ea27bac elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                    data-id="2ea27bac" data-element_type="section">
                                    <div class="elementor-container elementor-column-gap-default">
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-74ea8c6b"
                                            data-id="74ea8c6b" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-350264c elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="350264c" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>credit checks of brokers</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-19544159"
                                            data-id="19544159" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-f39a26c elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="f39a26c" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>Personal dispatcher</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-5842e64e"
                                            data-id="5842e64e" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-07db07f elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="07db07f" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>Request quick pay</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                <section
                                    class="elementor-section elementor-inner-section elementor-element elementor-element-ac351ae elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                    data-id="ac351ae" data-element_type="section">
                                    <div class="elementor-container elementor-column-gap-default">
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-4a5294b"
                                            data-id="4a5294b" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-882e74d elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="882e74d" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>Request fuel advances</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-aebda8d"
                                            data-id="aebda8d" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-f69503a elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="f69503a" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>24/7 dispatch support</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-7366565"
                                            data-id="7366565" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-f1ef44e elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="f1ef44e" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>Request insurance certificate</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                <section
                                    class="elementor-section elementor-inner-section elementor-element elementor-element-3ed61cd elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                    data-id="3ed61cd" data-element_type="section">
                                    <div class="elementor-container elementor-column-gap-default">
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-ec39439"
                                            data-id="ec39439" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-f9a55c5 elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="f9a55c5" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>driver director assistance</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-2ada5e7"
                                            data-id="2ada5e7" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-d436e60 elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="d436e60" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>negotiate quick pay rates</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-024851f"
                                            data-id="024851f" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-05e9ffa elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="05e9ffa" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>Factoring setup assistance</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                <section
                                    class="elementor-section elementor-inner-section elementor-element elementor-element-0873e05 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                    data-id="0873e05" data-element_type="section">
                                    <div class="elementor-container elementor-column-gap-default">
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-1eac6ba"
                                            data-id="1eac6ba" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-118afc0 elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="118afc0" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>collection assistance</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-4eef9a8"
                                            data-id="4eef9a8" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-f4c2075 elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="f4c2075" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>detention charges assistance</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-347ffb1"
                                            data-id="347ffb1" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-b669d0e elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="b669d0e" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>truck order not used (TONU)</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                                <section
                                    class="elementor-section elementor-inner-section elementor-element elementor-element-3ed61cd elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                    data-id="3ed61cd" data-element_type="section">
                                    <div class="elementor-container elementor-column-gap-default">
                                        <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-ec39439"
                                            data-id="ec39439" data-element_type="column">
                                            <div class="elementor-widget-wrap elementor-element-populated">
                                                <div class="elementor-element elementor-element-f9a55c5 elementor-view-stacked elementor-position-left elementor-vertical-align-middle elementor-shape-square elementor-widget elementor-widget-icon-box"
                                                    data-id="f9a55c5" data-element_type="widget"
                                                    data-widget_type="icon-box.default">
                                                    <div class="elementor-widget-container">
                                                        <div class="elementor-icon-box-wrapper">
                                                            <div class="elementor-icon-box-icon">
                                                                <span class="elementor-icon elementor-animation-">
                                                                    <i aria-hidden="true" class="fa fa-check"></i>
                                                                </span>
                                                            </div>
                                                            <div class="elementor-icon-box-content">
                                                                <h3 class="elementor-icon-box-title">
                                                                    <span>
                                                                        SEND YOU INVOICES EVERY WEEK</span>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </section>
                            </div>
                        </div>
                    </div>

                   

                </section>
                
            </div>
        </div>



    <section class="testimonial spad set-bg" data-setbg="img/testimonial/testimonial-bg.jpg">
        <div class="container">
            <div class="row">

                <div class="col-lg-12 offset-lg-4">
                    <div class="request__form">
                        <div class="section-title">
                            <span class="gold">Contacts Us</span>
                            <h2>Request A Call Back</h2>
                        </div>
                        <form action="/" method="post" id="formm" name="formm">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <input type="text" placeholder="Enter your name" id="nm" name="nm">
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <input type="text" placeholder="Enter your email" id="em" name="em">
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <input type="text" placeholder="Enter your phone number" id="ph" name="ph">
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6">
                                    <input type="text" placeholder="Subject" id="sb" name="sb">
                                </div>
                                <div class="col-lg-12">
                                    <textarea placeholder="Message" id="msg" name="msg"></textarea>
                                    <button style="float: right;" type="submit" class="site-btn bg-gold"
                                        onclick="myFunction()"><span>Submit
                                            Now</span></button>
                                   <!-- <button style="float: right;" type="reset" class="site-btn"
                                        value="Reset"><span>Reset
                                            Now</span></button>-->
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--*****************************************************************-->


    <div id="content" class="site-content ">
        
        <div id="content" class="site-content ">
        <div data-elementor-type="wp-page" data-elementor-id="554" class="elementor elementor-554"
            data-elementor-settings="[]">
            <div class="elementor-section-wrap">
            <section
                    class="elementor-section elementor-top-section elementor-element elementor-element-c3771bb elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="c3771bb" data-element_type="section"
                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-background-overlay"></div>
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-67480de"
                            data-id="67480de" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-6171358 elementor-widget elementor-widget-heading"
                                    data-id="6171358" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">Still Have Some
                                            Questions Left?</h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-d8642fb elementor-widget elementor-widget-heading"
                                    data-id="d8642fb" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">Call us at
                                            +1-516-246-6566</h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-d51244d elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                                    data-id="d51244d" data-element_type="widget" data-widget_type="divider.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-divider">
                                            <span class="elementor-divider-separator">
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-ada5094 elementor-widget elementor-widget-text-editor"
                                    data-id="ada5094" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <p>Feel free to contact our support team to learn more about the services
                                            provided by us.</p>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-4bc7cc6 elementor-align-center elementor-widget elementor-widget-button"
                                    data-id="4bc7cc6" data-element_type="widget" data-widget_type="button.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-button-wrapper">
                                            <a href="./contact.php"
                                                class="elementor-button-link elementor-button elementor-size-sm bg-gold"
                                                role="button">
                                                <span class="elementor-button-content-wrapper">
                                                    <span class="elementor-button-text">contact us</span>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </section><br>





        <footer class="footer bg-gold">

            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="footer__about">
                            <div class="footer__logo">
                                <a href="./index.php"><img src="./img/new_logo.png" alt=""></a>
                            </div>
                            <p>We’re a professional freight dispatching company with proven experience in the field.
                                Our team helps you get the most profitable loads to deliver. We generate high quality
                                and converting leads, providing you all the documents. Making business efficient for
                                both
                                parties.
                            </p>
                            <div class="footer__social">
                                <a href="#"><span class="social_facebook"></span></a>
                                <a href="#"><span class="social_twitter"></span></a>
                                <a href="#"><span class="social_linkedin"></span></a>
                                <a href="#"><span class="social_pinterest"></span></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 offset-lg-1 col-md-6 col-sm-6">
                        <div class="footer__widget">
                            <h5>Quick links</h5>
                            <ul>
                                <li><a href="./about.php">History</a></li>
                                <li><a href="./Dry-van.php">DRY VAN DISPATCH SERVICE</a></li>
                                <li><a href="./Owner-operator.php">OWNER OPERATOR SERVICE</a></li>
                                <li><a href="./Power-only.php">POWER ONLY DISPATCH SERVICE</a></li>
                                <li><a href="./Reefer.php">REEFER DISPATCH SERVICE</a></li>
                                <li><a href="./conditions.php">Terms & Conditions</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="footer__widget">
                            <h5>Contacts</h5>
                            <ul class="address">
                                <li><span class="icon_pin"></span><a href="https://goo.gl/maps/Xs7t8fcVACHGszMh8">978
                                        Hempstead Tpke,Franklin Sq,US</a></li>
                                <li><span class="icon_phone"></span><a href="tel:5554280940"> +1-516-246-6566</a></li>
                                <li><span class="icon_mail"></span> <a href="mailto:Info@paramountservices.com"
                                        class="__cf_email__"
                                        data-cfemail="b3daddd5dc9dd0dcdfdcdfdad1f3d4ded2dadf9dd0dcde">Info@paramountservices.com</a>
                                </li>
                            </ul>


                        </div>
                    </div>
                </div>
            </div>
            <div class="footer__copyright">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-9 col-md-8">
                            <div class="footer__copyright__text">

                                <p>Copyright &copy;
                                    <script data-cfasync="false" src="#"></script>
                                    <script>document.write(new Date().getFullYear());</script> All rights reserved
                                </p>
                            </div>
                        </div>
                        <!----
                            <div class="col-lg-3 col-md-4">
                                <div class="footer__copyright__links">
                                    <a href="#">Client Login</a>
                                    <a href="#">Join Team</a>
                                </div>
                            </div>-->
                    </div>
                </div>
            </div>
        </footer>

    </div><!-- #content -->

    <!--****************************************************************-->

    <div class="search-model">
        <div class="h-100 d-flex align-items-center justify-content-center">
            <div class="search-close-switch">+</div>
            <form class="search-model-form">
                <input type="text" id="search-input" placeholder="Search here.....">
            </form>
        </div>
    </div>





    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="./sources/jquery.js"></script>
    <script>eval(mod_pagespeed_EJfk9gGSrQ);</script>
    <script>eval(mod_pagespeed_vadjZYzCTr);</script>
    <script>eval(mod_pagespeed_QwdlkBSDSA);</script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

    <script async src="./sources/tagmanager.js"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');
        function myFunction() {
            var a = document.getElementById("nm").value;
            var b = document.getElementById("ph").value;
            var c = document.getElementById("msg").value;
            var d = document.getElementById("em").value;
            if (a.length == 0 || b.length == 0 || c.length == 0 || d.length == 0) {
                alert("Please fill all the fields");
                document.formm.action = "index.php";
            } else {
                /*alert("You will receive a call back with in a couple of hours.");
                document.getElementById("nm").value = "";
                document.getElementById("ph").value = "";
                document.getElementById("msg").value = "";
                document.getElementById("em").value = "";*/
                document.formm.action = "connect.php";
                
            }

        }

    </script>
    <script defer src="./sources/cloudflare.js"></script>
    <!--
    <script type='text/javascript'
        src='./sources/slider-pro-min7.js'
        id='kava-theme-script-js'></script>-->
</body>

</html>