<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Freight-Broker Template">
    <meta name="keywords" content="Freight-Broker, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1' >
    <meta property="og:locale" content="en_US" />
	<meta property="og:type" content="website" />
	<meta property="og:title" content="Fracktech: Top-Notch Web Development Company" />
	<meta property="og:description" content="Fracktech is a web development company that designs and develops stunning web applications and responsive content for all types businesses." />
	<meta property="og:url" content="https://fracktechnologies.com/" />
	<meta property="og:site_name" content="Fracktech" />
	<meta property="article:modified_time" content="2021-07-12T07:37:07+00:00" />
    <title>Paramount-Dispatch | About</title>
    <style>
        .gold{
            color : #d0ae66 !important;
        }
        .bg-gold{
            background : #d0ae66 !important;
        }
    </style>

    <link href="./sources/fontsgoogle.css"
        rel="stylesheet">
    <link href="./sources/fontsgoogle2.css" rel="stylesheet">

    <link rel="stylesheet"
        href="./sources/bootstrap.css"
        type="text/css" />
</head>

<body>

    <div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
        <div class="offcanvas__search__option">
            <span class="icon_search search-switch"></span>
        </div>
        <div class="offcanvas__logo">
            <a href="./index.php">
                <img src="img/xfooter-logo.png.pagespeed.ic.QfQCJiQvaR.webp" alt="">
            </a>
        </div>
        <div id="mobile-menu-wrap"></div>
        <ul class="offcanvas__widget">
            <li><span class="icon_phone"></span> +1-516-246-6566</li>
            <li><span class="icon_pin"></span> 978 Hempstead Tpke, Franklin Sq, NY, US</li>
        </ul>
        <div class="offcanvas__auth">
            <a href="#"><span class="icon_profile"></span> Register or Sign in</a>
        </div>
        <div class="offcanvas__social">
            <a href="#"><span class="social_facebook"></span></a>
            <a href="#"><span class="social_twitter"></span></a>
            <a href="#"><span class="social_linkedin"></span></a>
            <a href="#"><span class="social_pinterest"></span></a>
        </div>
    </div>


    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 offset-lg-3">
                        <ul class="header__top__widget">
                            <li><span class="icon_phone"></span> +1-516-246-6566</li>
                            <li><span class="icon_pin"></span> 978 Hempstead Tpke, Franklin Sq, NY, US</li>
                        </ul>
                        <div class="header__top__right">
                            <div class="header__top__right__auth">
                                <a href="#"><span class="icon_profile"></span> Register or Sign in</a>
                            </div>
                            <div class="header__top__right__social">
                                <a href="#"><span class="social_facebook"></span></a>
                                <a href="#"><span class="social_twitter"></span></a>
                                <a href="#"><span class="social_linkedin"></span></a>
                                <a href="#"><span class="social_pinterest"></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header__options">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="header__logo">
                            <a href="./index.php"><img src="img/new_logo.png" alt=""></a>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <nav class="header__menu mobile-menu">
                            <ul>
                                <li ><a href="./index.php">Home</a></li>
                                <li><a href="./services.php">Services</a> </li>
                                <li class="active"><a href="./about.php">About</a></li>

                                <li><a href="./Pricing.php">Pricing</a></li>
                                <li><a href="./Carrier.php">Carrier-Setup</a></li>
                                <li><a href="./Faq.php">FAQs</a></li>

                                <li><a href="./contact.php">Contacts</a></li>
                            </ul>
                        </nav>
                    </div>
                    
                    
                </div>
            </div>
            <div class="canvas__open"><i class="fa fa-bars"></i></div>
        </div>
    </header>


    <div class="breadcrumb-option set-bg" data-setbg="img/breadcrumb-bg.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb__text">
                        <h2>About Company</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <section class="about-company spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="section-title">
                        <h2>Welcome to the Paramount Dispatch company of delevery</h2>
                    </div>
                </div>
                <div class="col-lg-5 offset-lg-2">
                    <div class="about__company__title">
                        <p>Transport offers a host of logistic management services and supply chain solutions. We
                            provide innovative solutions with the best people, processes, and technology to drive
                            uncommon value for your company.</p>
                    </div>
                </div>
            </div>


            

            <div class="about__company__counter">
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <!--<div class="counter__item">
                            <img src="img/about/xci-1.png.pagespeed.ic.HIrfYE8pyg.webp" alt=""
                                data-pagespeed-url-hash="228777101"
                                onload="pagespeed.CriticalImages.checkImageForCriticality(this);">
                            <div class="counter__item__num">
                                <h2 class="c_num">9123</h2>
                            </div>
                        </div>-->
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <!--<div class="counter__item">
                            <img src="img/about/xci-2.png.pagespeed.ic.VFv3w34fqB.webp" alt=""
                                data-pagespeed-url-hash="523277022"
                                onload="pagespeed.CriticalImages.checkImageForCriticality(this);">
                            <div class="counter__item__num">
                                <h2 class="c_num">70102</h2>
                                <strong>km</strong>
                            </div>
                        </div>-->
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <!--<div class="counter__item">
                            <img src="img/about/xci-3.png.pagespeed.ic.5B16dXuFMP.webp" alt=""
                                data-pagespeed-url-hash="817776943"
                                onload="pagespeed.CriticalImages.checkImageForCriticality(this);">
                            <div class="counter__item__num">
                                <h2 class="c_num">1254</h2>
                            </div>
                        </div>-->
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <!--<div class="counter__item">
                            <img src="img/about/xci-4.png.pagespeed.ic.3m9cBZMQim.webp" alt=""
                                data-pagespeed-url-hash="1112276864"
                                onload="pagespeed.CriticalImages.checkImageForCriticality(this);">
                            <div class="counter__item__num">
                                <h2 class="c_num">20254</h2>
                            </div>
                        </div>-->
                    </div>
                </div>
            </div>
            <!------------------------------------------->
            <div class="section-title">
                <!--<div class="container">-->
                <div class="row">
                    <div class="col-lg-5">
                        <span class="gold">Our Duty</span>
                        <h2>What Do We Do</h2>
                        
                    </div>
                    <div class="about__company__title">
                        <div class="col-lg-12">
                            <p>We’re a professional truck dispatching company with proven experience in the field.
                                Our team helps you get the most profitable loads to deliver. We generate high quality
                                and converting leads, providing you with all the necessary documents. Making business
                                efficient for both parties. So you can focus on growing your business while we handle
                                the rest.</p>
                        </div>
                        
                    </div>
                </div>
                <!--</div>-->
            </div>

            <!------------------------------------------->
            <div class="section-title">
                <!--<div class="container">-->
                <div class="row">
                    <div class="col-lg-6">
                        <span class="gold">Mission</span>
                        <h2>Keep Your Fleet Up On The Road</h2>
                        
                    </div>
                    <div class="about__company__title">
                        <div class="col-lg-12">
                            <p>We keep your truck & fleet up & running on the road with high quality dispatch loads that
                                 generates you the best  profit. Our prices are reasonable for every budget. No matter what
                                  type of dispatch loads you require, we’ve got you covered.</p>
                        </div>
                        
                    </div>
                </div>
                <!--</div>-->
            </div>

            <!------------------------------------------->
            <div class="section-title">
                <!--<div class="container">-->
                <div class="row">
                    <div class="col-lg-6">
                        <span class="gold">Who We Are</span>
                        <h2>About Us</h2>
                        
                    </div>
                    <div class="about__company__title">
                        <div class="col-lg-12">
                            <p>PDS arranges skilled dispatch services for owner operators & truckers who are tired 
                                of wasting their time & energy on cheap freight. Have PDS prospect top paying loads
                                 while you drive. In addition, we can handle the rest of your administrative overhead 
                                 such as negotiating rates and handling necessary paperwork. We have multiple dispatch 
                                 service plans to choose from. Imagine never having to endlessly search load boards or
                                  fill out and fax paperwork again. We take care of the busy work so you can do what your
                                   paid to do – drive. Bottom line, our dispatch services help save truckers time & money.
                                    Paramount Dispatch Services saves time & money with our professional truck dispatch services. 
                                    It’s that simple.<br><br></p>
                            <p>Why Choose Paramount Dispatch Services!!! BECAUSE, we provide options on our flat-rate fees.
                                 You know what you want so we provide three separate plans to choose from. A Paperwork only,
                                  Basic and Professional plan. So why pay another trucking dispatch service 10% or more on 
                                  every load? Because of this, Carrier Dispatch Services came up with a ‘one stop shop’ for
                                   all your trucking dispatch needs. Whether you have a ‘hands on’ business approach & need
                                    the ‘paperwork only’ plan or would rather us handle everything, we can customize our 
                                    dispatching services to meet your needs. We understand the frustration truckers face
                                     being stuck at truck-stops, searching load boards, calling brokers with cheap freight,
                                      waiting for emails & paying for copies & faxes.</p>
                        </div>
                        
                    </div>
                </div>
                <!--</div>-->
            </div>



    </section>



    <section class="chooseus spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="chooseus__text">
                        <div class="section-title">
                            <span class="gold">Our Benefit</span>
                            <h2>Why People Choose Us?</h2>
                        </div>
                        <!--<p>With years of experience handling & managing dispatch services, we have proven ourselves as a professional in the industry. Our experience speaks for itself. By providing quality dispatch loads & friendly support, handling the hassle all by ourselves, all that with pricing that’s fit for every budget, we’ve gained our customers’ trust</p>-->
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="chooseus__item">
                                    <div class="chooseus__item__icon">
                                        <img src="img/chooseus/xci-3.png.pagespeed.ic.XA8Lr9wN0Q.webp" alt="">
                                    </div>
                                    <div class="chooseus__item__text">
                                        <h5>Experience</h5>
                                        <p>With years of experience handling & managing dispatch services, we have
                                            proven ourselves as a professional in the industry.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="chooseus__item">
                                    <div class="chooseus__item__icon">
                                        <img src="img/chooseus/xci-1.png.pagespeed.ic.eXfk6xEhqR.webp" alt="">
                                    </div>
                                    <div class="chooseus__item__text">
                                        <h5>Quality Dispatch</h5>
                                        <p>By providing quality dispatch loads & friendly support, handling the hassle
                                            all by ourselves, all that with pricing that’s fit for every budget.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="chooseus__item">
                                    <div class="chooseus__item__icon">
                                        <img src="img/chooseus/xci-2.png.pagespeed.ic.yjtio_xhjE.webp" alt="">
                                    </div>
                                    <div class="chooseus__item__text">
                                        <h5>Custormer's Trust</h5>
                                        <p>Our experience speaks for itself, and we’ve gained our customers’ trust.</p>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <div class="chooseus__pic set-bg" data-setbg="img/chooseus/Choose.jpg"></div>
        </div>
    </section>


    <section class="history spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="history__item">
                        <span>1</span>
                        <h2>History</h2>
                        <p>We’re a professional freight dispatching company with proven experience 
                            in the field. Our team helps you get the most profitable loads to deliver on time with a very low cost and high efficiency.</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="history__item">
                        <span>2</span>
                        <h2>Mission</h2>
                        <p>We keep your truck & fleet up running on the road with high quality
                            loads that generates you the best  profit. No matter what type of dispatch loads you require, we’ve got you covered.</p>
                    </div>
                </div>
                <!-- <div class="col-lg-4 col-md-6">
                    <div class="history__item">
                        <span>3</span>
                        <h2>Vision</h2>
                        <p>PDS arranges skilled dispatch services for owner operators & truckers who are tired. In addition,
                             we can handle the rest of your administrative overhead such as negotiating rates and handling necessary paperwork. </p>
                    </div>
                </div> -->
            </div>
        </div>
    </section>


    <!-- <section class="callto spad set-bg" data-setbg="img/call-bg.jpg">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-8">
                    <div class="callto__text text-center">
                        <h2>You have one number to call, receive one reconciled invoice for all </h2>
                        <a href="./contact.php" class="primary-btn bg-gold"><span>Call Us Now</span></a>
                    </div>
                </div>
            </div>
        </div>
    </section><br> -->

<!----
    <section class="team spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="section-title">
                        <span>Our expert</span>
                        <h2>Meet Our Team Member</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team__item set-bg" data-setbg="img/team/team-1.jpg">
                        <div class="team__item__title">
                            <h6>Milley cyrus / <span>Support</span></h6>
                        </div>
                        <ul class="team__item__social">
                            <li><a href="#"><span class="social_facebook"></span></a></li>
                            <li><a href="#"><span class="social_twitter"></span></a></li>
                            <li><a href="#"><span class="social_linkedin"></span></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team__item set-bg" data-setbg="img/team/team-2.jpg">
                        <div class="team__item__title">
                            <h6>John Smith / <span>Support</span></h6>
                        </div>
                        <ul class="team__item__social">
                            <li><a href="#"><span class="social_facebook"></span></a></li>
                            <li><a href="#"><span class="social_twitter"></span></a></li>
                            <li><a href="#"><span class="social_linkedin"></span></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team__item set-bg" data-setbg="img/team/team-3.jpg">
                        <div class="team__item__title">
                            <h6>Becky Taylor / <span>Support</span></h6>
                        </div>
                        <ul class="team__item__social">
                            <li><a href="#"><span class="social_facebook"></span></a></li>
                            <li><a href="#"><span class="social_twitter"></span></a></li>
                            <li><a href="#"><span class="social_linkedin"></span></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="team__item set-bg" data-setbg="img/team/team-4.jpg">
                        <div class="team__item__title">
                            <h6>Martin Tom / <span>Support</span></h6>
                        </div>
                        <ul class="team__item__social">
                            <li><a href="#"><span class="social_facebook"></span></a></li>
                            <li><a href="#"><span class="social_twitter"></span></a></li>
                            <li><a href="#"><span class="social_linkedin"></span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>-->


    <footer class="footer bg-gold">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="footer__about">
                        <div class="footer__logo">
                            <a href="./index.php"><img src="./img/new_logo.png" alt=""></a>
                        </div>
                        <p>We’re a professional freight dispatching company with proven experience in the field.
                             Our team helps you get the most profitable loads to deliver. We generate high quality 
                             and converting leads, providing you all the documents. Making business efficient for both parties.
                        </p>
                        <div class="footer__social">
                            <a href="#"><span class="social_facebook"></span></a>
                            <a href="#"><span class="social_twitter"></span></a>
                            <a href="#"><span class="social_linkedin"></span></a>
                            <a href="#"><span class="social_pinterest"></span></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 offset-lg-1 col-md-6 col-sm-6">
                    <div class="footer__widget">
                        <h5>Quick links</h5>
                        <ul>
                                <li><a href="./about.php">History</a></li>
                                <li><a href="./Dry-van.php">DRY VAN DISPATCH SERVICE</a></li>
                                <li><a href="./Owner-operator.php">OWNER OPERATOR SERVICE</a></li>
                                <li><a href="./Power-only.php">POWER ONLY DISPATCH SERVICE</a></li>
                                <li><a href="./Reefer.php">REEFER DISPATCH SERVICE</a></li>
                                <li><a href="./conditions.php">Terms & Conditions</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="footer__widget">
                        <h5>Contacts</h5>
                        <ul class="address">
                            <li><span class="icon_pin"></span><a href="https://goo.gl/maps/Xs7t8fcVACHGszMh8" >978 Hempstead Tpke,Franklin Sq,US</a></li>
                            <li><span class="icon_phone" ></span><a href="tel:5554280940"> +1-516-246-6566</a></li>
                            <li><span class="icon_mail"></span> <a href="mailto:Info@paramountservices.com"
                                    class="__cf_email__"
                                    data-cfemail="b3daddd5dc9dd0dcdfdcdfdad1f3d4ded2dadf9dd0dcde">Info@paramountservices.com</a>
                            </li>
                        </ul>
                        
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="footer__copyright">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-8">
                        <div class="footer__copyright__text">

                            <p>Copyright &copy;
                                <script data-cfasync="false"
                                    src="#"></script>
                                <script>document.write(new Date().getFullYear());</script> All rights reserved
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>


    <div class="search-model">
        <div class="h-100 d-flex align-items-center justify-content-center">
            <div class="search-close-switch">+</div>
            <form class="search-model-form">
                <input type="text" id="search-input" placeholder="Search here.....">
            </form>
        </div>
    </div>


    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="./sources/jquery.js"></script>
    <script>eval(mod_pagespeed_EJfk9gGSrQ);</script>
    <script>eval(mod_pagespeed_vadjZYzCTr);</script>
    <script>eval(mod_pagespeed_QwdlkBSDSA);</script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

    <script async src="./sources/tagmanager.js"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');
    </script>
    <script defer src="./sources/cloudflare.js"
        ></script>
</body>

</html>