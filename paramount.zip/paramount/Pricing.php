<!DOCTYPE html>
<html>

<head>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <meta charset="UTF-8">
    <meta name="description" content="Freight-Broker Template">
    <meta name="keywords" content="Freight-Broker, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1'>
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Fracktech: Top-Notch Web Development Company" />
    <meta property="og:description"
        content="Fracktech is a web development company that designs and develops stunning web applications and responsive content for all types businesses." />
    <meta property="og:url" content="https://fracktechnologies.com/" />
    <meta property="og:site_name" content="Fracktech" />
    <meta property="article:modified_time" content="2021-07-12T07:37:07+00:00" />
    <title>Paramount-Dispatch | Pricing</title>
    <style>
        .gold{
            color : #d0ae66 !important;
        }
        .bg-gold{
            background : #d0ae66 !important;
        }
    </style>
    </style>

    <script type='text/javascript' src='./sources/jquerymin.js' id='jquery-core-js'></script>


    <link href="./sources/fontsgoogle.css" rel="stylesheet">
    <link href="./sources/fontsgoogle2.css" rel="stylesheet">

    <link rel="stylesheet" href="./sources/bootstrap.css" type="text/css" />

    <link rel='stylesheet' id='google-fonts-1-css' href='./sources/gooleaps.css' type='text/css' media='all' />

    
    <link rel='stylesheet' id='wpacu-combined-css-head-1'
        href='./sources/pricing.css'
        type='text/css' media='all' />


</head>

<body>
    <div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
        <div class="offcanvas__search__option">
            <span class="icon_search search-switch"></span>
        </div>
        <div class="offcanvas__logo">
            <a href="./index.php">
                <img src="img/xfooter-logo.png.pagespeed.ic.QfQCJiQvaR.webp" alt="">
            </a>
        </div>
        <div id="mobile-menu-wrap"></div>
        <ul class="offcanvas__widget">
            <li><span class="icon_phone"></span> +1-516-246-6566</li>
            <li><span class="icon_pin"></span> 978 Hempstead Tpke, Franklin Sq, NY, US</li>
        </ul>
        <div class="offcanvas__auth">
            <a href="#"><span class="icon_profile"></span> Register or Sign in</a>
        </div>
        <div class="offcanvas__social">
            <a href="#"><span class="social_facebook"></span></a>
            <a href="#"><span class="social_twitter"></span></a>
            <a href="#"><span class="social_linkedin"></span></a>
            <a href="#"><span class="social_pinterest"></span></a>
        </div>
    </div>
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 offset-lg-3">
                        <ul class="header__top__widget">
                            <li><span class="icon_phone"></span> +1-516-246-6566</li>
                            <li><span class="icon_pin"></span> 978 Hempstead Tpke, Franklin Sq, NY, US</li>
                        </ul>
                        <div class="header__top__right">
                            <div class="header__top__right__auth">
                                <a href="#"><span class="icon_profile"></span> Register or Sign in</a>
                            </div>
                            <div class="header__top__right__social">
                                <a href="#"><span class="social_facebook"></span></a>
                                <a href="#"><span class="social_twitter"></span></a>
                                <a href="#"><span class="social_linkedin"></span></a>
                                <a href="#"><span class="social_pinterest"></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header__options">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="header__logo">
                            <a href="./index.php"><img src="img/new_logo.png" alt=""></a>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <nav class="header__menu mobile-menu">
                            <ul>
                                <li ><a href="./index.php">Home</a></li>
                                <li><a href="./services.php">Services</a> </li>
                                <li><a href="./about.php">About</a></li>

                                <li class="active"><a href="./Pricing.php">Pricing</a></li>
                                <li><a href="./Carrier.php">Carrier-Setup</a></li>
                                <li><a href="./Faq.php">FAQs</a></li>

                                <li><a href="./contact.php">Contacts</a></li>
                            </ul>
                        </nav>
                    </div>
                    

                </div>
            </div>
            <div class="canvas__open"><i class="fa fa-bars"></i></div>
        </div>

    </header><!-- #masthead -->
        <div id="content" class="site-content ">
            <div data-elementor-type="wp-page" data-elementor-id="1088" class="elementor elementor-1088"
                data-elementor-settings="[]">
                <div class="elementor-section-wrap">
                    <section
                        class="elementor-section elementor-top-section elementor-element elementor-element-d4f8c48 elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                        data-id="d4f8c48" data-element_type="section">
                        <div class="elementor-container elementor-column-gap-default">
                            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-ba53015"
                                data-id="ba53015" data-element_type="column">
                                <div class="elementor-widget-wrap elementor-element-populated">
                                    <div class="elementor-element elementor-element-442f325 elementor-widget elementor-widget-heading"
                                        data-id="442f325" data-element_type="widget" data-widget_type="heading.default">
                                        <div class="elementor-widget-container">
                                            <h2 class="elementor-heading-title elementor-size-default">Flexible prices
                                            </h2>
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-aac7b4a elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                                        data-id="aac7b4a" data-element_type="widget" data-widget_type="divider.default">
                                        <div class="elementor-widget-container">
                                            <div class="elementor-divider">
                                                <span class="elementor-divider-separator">
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="elementor-element elementor-element-1f7517e elementor-widget elementor-widget-heading"
                                        data-id="1f7517e" data-element_type="widget" data-widget_type="heading.default">
                                        <div class="elementor-widget-container">
                                            <h2 class="elementor-heading-title elementor-size-default">Pricing</h2>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <section
                        class="elementor-section elementor-top-section elementor-element elementor-element-4f8707a elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                        data-id="4f8707a" data-element_type="section">
                        <div class="elementor-container elementor-column-gap-default">
                            <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-0040780"
                                data-id="0040780" data-element_type="column">
                                <div class="elementor-widget-wrap elementor-element-populated">
                                    <div class="elementor-element elementor-element-6bf0284 elementor-widget elementor-widget-jet-accordion"
                                        data-id="6bf0284" data-element_type="widget"
                                        data-widget_type="jet-accordion.default">
                                        <div class="elementor-widget-container">
                                            <div class="jet-accordion"
                                                data-settings="{&quot;collapsible&quot;:false,&quot;ajaxTemplate&quot;:false}"
                                                role="tablist">
                                                <div class="jet-accordion__inner">
                                                    <div
                                                        class="jet-accordion__item jet-toggle jet-toggle-move-up-effect active-toggle">
                                                        <div id="jet-toggle-control-1131"
                                                            class="jet-toggle__control elementor-menu-anchor"
                                                            data-toggle="1" role="tab"
                                                            aria-controls="jet-toggle-content-1131" aria-expanded="true"
                                                            data-template-id="1655">
                                                           
                                                        </div>
                                                        <div id="jet-toggle-content-1131" class="jet-toggle__content"
                                                            data-toggle="1" role="tabpanel" aria-hidden="false"
                                                            data-template-id="1655">
                                                            <div class="jet-toggle__content-inner">
                                                                <div data-elementor-type="page" data-elementor-id="1655"
                                                                    class="elementor elementor-1655"
                                                                    data-elementor-settings="[]">
                                                                    <div class="elementor-section-wrap">
                                                                        <section
                                                                            class="elementor-section elementor-top-section elementor-element elementor-element-abffd4d elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                                                                            data-id="abffd4d"
                                                                            data-element_type="section">
                                                                            <div
                                                                                class="elementor-container elementor-column-gap-default">
                                                                                <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-b6e11f0"
                                                                                    data-id="b6e11f0"
                                                                                    data-element_type="column"
                                                                                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                                                                                    <div
                                                                                        class="elementor-widget-wrap elementor-element-populated">
                                                                                        <section
                                                                                            class="elementor-section elementor-inner-section elementor-element elementor-element-8914f7d elementor-section-full_width elementor-section-height-default elementor-section-height-default"
                                                                                            data-id="8914f7d"
                                                                                            data-element_type="section">
                                                                                            <div
                                                                                                class="elementor-container elementor-column-gap-default">
                                                                                                <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-8d0d26a"
                                                                                                    data-id="8d0d26a"
                                                                                                    data-element_type="column">
                                                                                                    <div
                                                                                                        class="elementor-widget-wrap elementor-element-populated">
                                                                                                        <div class="elementor-element elementor-element-2e30ebb elementor-widget elementor-widget-jet-headline"
                                                                                                            data-id="2e30ebb"
                                                                                                            data-element_type="widget"
                                                                                                            data-widget_type="jet-headline.default">
                                                                                                            <div
                                                                                                                class="elementor-widget-container">
                                                                                                                <h2
                                                                                                                    class="jet-headline jet-headline--direction-vertical">
                                                                                                                    <span
                                                                                                                        class="jet-headline__part jet-headline__first"><span
                                                                                                                            class="jet-headline__deco jet-headline__deco-icon"><i
                                                                                                                                aria-hidden="true"
                                                                                                                                class="fas fa-dollar-sign"></i></span><span
                                                                                                                            class="jet-headline__label">Pay</span></span><span
                                                                                                                        class="jet-headline__part jet-headline__second"><span
                                                                                                                            class="jet-headline__label gold">weekly</span></span>
                                                                                                                </h2>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="elementor-element elementor-element-03fcf01 elementor-widget elementor-widget-heading"
                                                                                                            data-id="03fcf01"
                                                                                                            data-element_type="widget"
                                                                                                            data-widget_type="heading.default">
                                                                                                            <div
                                                                                                                class="elementor-widget-container">
                                                                                                                <h2
                                                                                                                    class="elementor-heading-title elementor-size-default">
                                                                                                                    $300
                                                                                                                    per
                                                                                                                    week
                                                                                                                </h2>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-6c0578a"
                                                                                                    data-id="6c0578a"
                                                                                                    data-element_type="column">
                                                                                                    <div
                                                                                                        class="elementor-widget-wrap elementor-element-populated">
                                                                                                        <div class="elementor-element elementor-element-9e8fe11 elementor-widget elementor-widget-heading"
                                                                                                            data-id="9e8fe11"
                                                                                                            data-element_type="widget"
                                                                                                            data-widget_type="heading.default">
                                                                                                            <div
                                                                                                                class="elementor-widget-container bg-gold">
                                                                                                                <h2
                                                                                                                    class="elementor-heading-title elementor-size-default">
                                                                                                                    Recommended
                                                                                                                </h2>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="elementor-element elementor-element-c5d6bf1 elementor-widget elementor-widget-jet-headline"
                                                                                                            data-id="c5d6bf1"
                                                                                                            data-element_type="widget"
                                                                                                            id="paymonth"
                                                                                                            data-widget_type="jet-headline.default">
                                                                                                            <div
                                                                                                                class="elementor-widget-container">
                                                                                                                <h2
                                                                                                                    class="jet-headline jet-headline--direction-vertical">
                                                                                                                    <span
                                                                                                                        class="jet-headline__part jet-headline__first"><span
                                                                                                                            class="jet-headline__deco jet-headline__deco-icon"><i
                                                                                                                                aria-hidden="true"
                                                                                                                                class="fas fa-dollar-sign"></i></span><span
                                                                                                                            class="jet-headline__label">Pay</span></span><span
                                                                                                                        class="jet-headline__part jet-headline__second"><span
                                                                                                                            class="jet-headline__label gold">monthly</span></span>
                                                                                                                </h2>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="elementor-element elementor-element-7010a80 elementor-hidden-phone elementor-widget elementor-widget-heading"
                                                                                                            data-id="7010a80"
                                                                                                            data-element_type="widget"
                                                                                                            data-widget_type="heading.default">
                                                                                                            <div
                                                                                                                class="elementor-widget-container">
                                                                                                                <h2
                                                                                                                    class="elementor-heading-title elementor-size-default">
                                                                                                                    <s>
                                                                                                                        $1200</s>
                                                                                                                    $999.00
                                                                                                                    per
                                                                                                                    month
                                                                                                                </h2>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="elementor-element elementor-element-2d9c317 elementor-hidden-desktop elementor-hidden-tablet elementor-widget elementor-widget-heading"
                                                                                                            data-id="2d9c317"
                                                                                                            data-element_type="widget"
                                                                                                            data-widget_type="heading.default">
                                                                                                            <div
                                                                                                                class="elementor-widget-container">
                                                                                                                <h2
                                                                                                                    class="elementor-heading-title elementor-size-default">
                                                                                                                    <s>
                                                                                                                        $1200</s>
                                                                                                                    $999.00/
                                                                                                                    month
                                                                                                                </h2>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <div class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-2ebf16b"
                                                                                                    data-id="2ebf16b"
                                                                                                    data-element_type="column">
                                                                                                    <div
                                                                                                        class="elementor-widget-wrap elementor-element-populated">
                                                                                                        <div class="elementor-element elementor-element-8dd92c6 elementor-widget elementor-widget-jet-headline"
                                                                                                            data-id="8dd92c6"
                                                                                                            data-element_type="widget"
                                                                                                            data-widget_type="jet-headline.default">
                                                                                                            <div
                                                                                                                class="elementor-widget-container">
                                                                                                                <h2
                                                                                                                    class="jet-headline jet-headline--direction-vertical">
                                                                                                                    <span
                                                                                                                        class="jet-headline__part jet-headline__first"><span
                                                                                                                            class="jet-headline__deco jet-headline__deco-icon"><i
                                                                                                                                aria-hidden="true"
                                                                                                                                class="fas fa-dollar-sign"></i></span><span
                                                                                                                            class="jet-headline__label">Pay</span></span><span
                                                                                                                        class="jet-headline__part jet-headline__second"><span
                                                                                                                            class="jet-headline__label gold">
                                                                                                                            6%</span></span>
                                                                                                                </h2>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <div class="elementor-element elementor-element-2b98ba4 elementor-widget elementor-widget-heading"
                                                                                                            data-id="2b98ba4"
                                                                                                            data-element_type="widget"
                                                                                                            data-widget_type="heading.default">
                                                                                                            <div
                                                                                                                class="elementor-widget-container">
                                                                                                                <h2
                                                                                                                    class="elementor-heading-title elementor-size-default">
                                                                                                                    Of
                                                                                                                    total
                                                                                                                    gross
                                                                                                                </h2>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </section>
                                                                                        <div class="elementor-element elementor-element-c209714 elementor-widget elementor-widget-text-editor"
                                                                                            data-id="c209714"
                                                                                            data-element_type="widget"
                                                                                            data-widget_type="text-editor.default">
                                                                                            <div
                                                                                                class="elementor-widget-container">
                                                                                                
                                                                                                <p><strong>Perks:</strong>
                                                                                                </p>
                                                                                                <ul>
                                                                                                    <li>You&#8217;re the
                                                                                                        boss</li>
                                                                                                    <li>No forced
                                                                                                        dispatch</li>
                                                                                                    <li>Pay load = 100%
                                                                                                        yours</li>
                                                                                                    <li>We negotiate top
                                                                                                        paying rates
                                                                                                    </li>
                                                                                                    <li>setup paperwork
                                                                                                    </li>
                                                                                                    <li>Fax/ email
                                                                                                        documents</li>
                                                                                                    <li>Credit checks of
                                                                                                        brokers</li>
                                                                                                    <li>Personal
                                                                                                        dispatcher</li>
                                                                                                    <li>Request quick
                                                                                                        pay</li>
                                                                                                    <li>Request fuel
                                                                                                        advances</li>
                                                                                                    <li>Request
                                                                                                        insurance
                                                                                                        certificate</li>
                                                                                                    <li>Driver director
                                                                                                        assistance </li>
                                                                                                    <li>collection
                                                                                                        assistance</li>
                                                                                                    <li>detention
                                                                                                        charges
                                                                                                        assistance</li>
                                                                                                    <li>truck order not
                                                                                                        used (TONU)</li>
                                                                                                    <li>Send you
                                                                                                        business reports
                                                                                                        every week</li>
                                                                                                    <li>No Term
                                                                                                        Commitments</li>
                                                                                                </ul>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </section>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="jet-accordion__item jet-toggle jet-toggle-move-up-effect active-toggle">
                                                        <div id="jet-toggle-control-1132"
                                                            class="jet-toggle__control elementor-menu-anchor"
                                                            data-toggle="2" role="tab"
                                                            aria-controls="jet-toggle-content-1132" aria-expanded="true"
                                                            data-template-id="false">
                                                            <div class="jet-toggle__label-text gold">Trucking Fleet</div>
                                                        </div>
                                                        <div id="jet-toggle-content-1132" class="jet-toggle__content"
                                                            data-toggle="2" role="tabpanel" aria-hidden="false"
                                                            data-template-id="false">
                                                            <div class="jet-toggle__content-inner">
                                                                <p><a href="#form"><strong class="gold">Contact us</strong></a>
                                                                    
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>

        </div><br><!-- #content -->

        <footer class="footer bg-gold">
                
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <div class="footer__about">
                            <div class="footer__logo">
                                <a href="./index.php"><img src="./img/new_logo.png" alt=""></a>
                            </div>
                            <p>We’re a professional freight dispatching company with proven experience in the field.
                                Our team helps you get the most profitable loads to deliver. We generate high quality
                                and converting leads, providing you all the documents. Making business efficient for both
                                parties.
                            </p>
                            <div class="footer__social">
                                <a href="#"><span class="social_facebook"></span></a>
                                <a href="#"><span class="social_twitter"></span></a>
                                <a href="#"><span class="social_linkedin"></span></a>
                                <a href="#"><span class="social_pinterest"></span></a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 offset-lg-1 col-md-6 col-sm-6">
                        <div class="footer__widget">
                            <h5><b>Quick links</b></h5>
                            <ul>
                                <li><a href="./about.php">History</a></li>
                                <li><a href="./Dry-van.php">DRY VAN DISPATCH SERVICE</a></li>
                                <li><a href="./Owner-operator.php">OWNER OPERATOR SERVICE</a></li>
                                <li><a href="./Power-only.php">POWER ONLY DISPATCH SERVICE</a></li>
                                <li><a href="./Reefer.php">REEFER DISPATCH SERVICE</a></li>
                                <li><a href="./conditions.php">Terms & Conditions</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="footer__widget">
                            <h5><b>Contacts</b></h5>
                            <ul class="address">
                                <li><span class="icon_pin"></span><a href="https://goo.gl/maps/Xs7t8fcVACHGszMh8">978
                                        Hempstead Tpke,Franklin Sq,US</a></li>
                                <li><span class="icon_phone"></span><a href="tel:5554280940"> +1-516-246-6566</a></li>
                                <li><span class="icon_mail"></span> <a href="mailto:Info@paramountservices.com"
                                        class="__cf_email__"
                                        data-cfemail="b3daddd5dc9dd0dcdfdcdfdad1f3d4ded2dadf9dd0dcde">Info@paramountservices.com</a>
                                </li>
                            </ul>
    
    
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer__copyright">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-9 col-md-8">
                            <div class="footer__copyright__text">
    
                                <p>Copyright &copy;
                                    <script data-cfasync="false" src="#"></script>
                                    <script>document.write(new Date().getFullYear());</script> All rights reserved
                                </p>
                            </div>
                        </div>
                        <!----
                        <div class="col-lg-3 col-md-4">
                            <div class="footer__copyright__links">
                                <a href="#">Client Login</a>
                                <a href="#">Join Team</a>
                            </div>
                        </div>-->
                    </div>
                </div>
            </div>
        </footer><!-- #colophon -->

    </div><!-- #page -->

    <link rel='stylesheet' id='elementor-post-1655-css'
        href='./sources/post-1655.css'
        type='text/css' media='all' />
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="./sources/jquery.js"></script>
    <script>eval(mod_pagespeed_EJfk9gGSrQ);</script>
    <script>eval(mod_pagespeed_vadjZYzCTr);</script>
    <script>eval(mod_pagespeed_QwdlkBSDSA);</script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

    <script async src="./sources/tagmanager.js"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');
    </script>
    <script defer src="./sources/cloudflare.js"
        ></script>
   

</body>

</html>