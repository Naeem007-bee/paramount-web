<?php
	
	$Name = $_POST['nm'];
	$Email = $_POST['em'];
	$Phone = $_POST['ph'];
	$Subject = $_POST['sb'];
	$Message = $_POST['msg'];
	$ip = $_SERVER['REMOTE_ADDR']; 

	// Database connection
	$conn = new mysqli('localhost','root','','test');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		    $stmt = $conn->prepare("insert into data(ip, name, email, phone, subject, message) values(?, ?, ?, ?, ?, ?)");
		    $stmt->bind_param("ssssss", $ip, $Name, $Email, $Phone, $Subject, $Message);
		    $execval = $stmt->execute();
		    echo $execval;
		    echo "Registration successfully...";
		    $stmt->close();
		    $conn->close();
	}
	header("Location:index.php");
	exit();
?>