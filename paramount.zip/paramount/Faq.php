<!DOCTYPE html>
<html>

<head>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <meta charset="UTF-8">
    <meta name="description" content="Freight-Broker Template">
    <meta name="keywords" content="Freight-Broker, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1'>
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Fracktech: Top-Notch Web Development Company" />
    <meta property="og:description"
        content="Fracktech is a web development company that designs and develops stunning web applications and responsive content for all types businesses." />
    <meta property="og:url" content="https://fracktechnologies.com/" />
    <meta property="og:site_name" content="Fracktech" />
    <meta property="article:modified_time" content="2021-07-12T07:37:07+00:00" />
    <title>Paramount-Dispatch | FAQ</title>
    <style>
        .gold{
            color : #d0ae66 !important;
        }
        .bg-gold{
            background : #d0ae66 !important;
        }
    </style>

    <link rel='stylesheet' id='wpacu-combined-css-head-1'
        href='./sources/faq.css'
        type='text/css' media='all' />

    <script type='text/javascript' src='./sources/jquerymin.js' id='jquery-core-js'></script>


    <link href="./sources/fontsgoogle.css" rel="stylesheet">
    <link href="./sources/fontsgoogle2.css" rel="stylesheet">

    <link rel="stylesheet" href="./sources/bootstrap.css" type="text/css" />

    <link rel='stylesheet' id='google-fonts-1-css' href='./sources/gooleaps.css' type='text/css' media='all' />


</head>

<body>
    <div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
        <div class="offcanvas__search__option">
            <span class="icon_search search-switch"></span>
        </div>
        <div class="offcanvas__logo">
            <a href="./index.php">
                <img src="img/xfooter-logo.png.pagespeed.ic.QfQCJiQvaR.webp" alt="">
            </a>
        </div>
        <div id="mobile-menu-wrap"></div>
        <ul class="offcanvas__widget">
            <li><span class="icon_phone"></span> +1-516-246-6566</li>
            <li><span class="icon_pin"></span> 978 Hempstead Tpke, Franklin Sq, NY, US</li>
        </ul>
        <div class="offcanvas__auth">
            <a href="#"><span class="icon_profile"></span> Register or Sign in</a>
        </div>
        <div class="offcanvas__social">
            <a href="#"><span class="social_facebook"></span></a>
            <a href="#"><span class="social_twitter"></span></a>
            <a href="#"><span class="social_linkedin"></span></a>
            <a href="#"><span class="social_pinterest"></span></a>
        </div>
    </div>

    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 offset-lg-3">
                        <ul class="header__top__widget">
                            <li><span class="icon_phone"></span> +1-516-246-6566</li>
                            <li><span class="icon_pin"></span> 978 Hempstead Tpke, Franklin Sq, NY, US</li>
                        </ul>
                        <div class="header__top__right">
                            <div class="header__top__right__auth">
                                <a href="#"><span class="icon_profile"></span> Register or Sign in</a>
                            </div>
                            <div class="header__top__right__social">
                                <a href="#"><span class="social_facebook"></span></a>
                                <a href="#"><span class="social_twitter"></span></a>
                                <a href="#"><span class="social_linkedin"></span></a>
                                <a href="#"><span class="social_pinterest"></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header__options">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="header__logo">
                            <a href="./index.php"><img src="img/new_logo.png" alt=""></a>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <nav class="header__menu mobile-menu">
                            <ul>
                                <li ><a href="./index.php">Home</a></li>
                                <li><a href="./services.php">Services</a> </li>
                                <li><a href="./about.php">About</a></li>

                                <li><a href="./Pricing.php">Pricing</a></li>
                                <li><a href="./Carrier.php">Carrier-Setup</a></li>
                                <li class="active"><a href="./Faq.php">FAQs</a></li>

                                <li><a href="./contact.php">Contacts</a></li>
                            </ul>
                        </nav>
                    </div>
                    

                </div>
            </div>
            <div class="canvas__open"><i class="fa fa-bars"></i></div>
        </div>

    </header><br>


    <header class="page-header">
        <h1 class="page-title">FAQs</h1>
    </header><!-- .page-header -->


    <div class="page-content">
        <div data-elementor-type="wp-page" data-elementor-id="1502" class="elementor elementor-1502"
            data-elementor-settings="[]">
            <div class="elementor-section-wrap">
                <section
                    class="elementor-section elementor-top-section elementor-element elementor-element-ce50500 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="ce50500" data-element_type="section">
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-e3f6a9f"
                            data-id="e3f6a9f" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-611acaa elementor-widget elementor-widget-heading"
                                    data-id="611acaa" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">Roles of a Shipper,
                                            broker, Dispatcher, and a truck driver</h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-f500e0e elementor-widget elementor-widget-text-editor"
                                    data-id="f500e0e" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <p><strong>Shipper : </strong>Shippers manufacture products and are looking for
                                            loyal drivers &amp; carriers to ship their products. Manufacturers have
                                            goods to be transported and they do face problems related to logistics &amp;
                                            transportation. In order to avoid this hassle, shippers are looking for
                                            brokers to find them the perfect equipment + driver to deliver their
                                            shipment.</p>
                                        <p><strong>Freight Broker : </strong>The backbone of the trucking business.
                                            Freight brokers are in touch with different shippers &amp; manufacturers who
                                            are looking for a reliable way to transport their loads. Brokers act as the
                                            bridge between shippers and drivers. They keep the drivers&#8217; fleet up
                                            &amp; running on the road, providing them with the most profitable loads to
                                            deliver + removing the goods transportation problems a shipper may face.</p>
                                        <p><strong>Truck driver : </strong>Drivers are simply people who deliver the
                                            loads to their destination. There maybe independent drivers who drive their
                                            own trucks and manage their fleet, or they&#8217;re working for another
                                            trucking company. Either way, truck drivers need their vehicle to be
                                            delivering loads all the time to keep their business running. </p>
                                        <p>However, drivers may not be able to handle all the tasks, including :</p>
                                        <ul>
                                            <li>Handling payments</li>
                                            <li>Negotiating rates</li>
                                            <li>Handling paperwork</li>
                                            <li>Booking loads</li>
                                        </ul>
                                        <p>In order for the drivers to keep delivering the loads + handling all other
                                            tasks, they require services of a &#8216;Dispatcher&#8217;.</p>
                                        <p><strong>Dispatcher : </strong>Just like Shippers face problems related to
                                            logistics and transport, Drivers may also face problems due to their busy
                                            schedule. A Dispatcher is in contact with the broker directly and acts on
                                            behalf of the driver to books loads, handle payments &amp; paperwork, so the
                                            driver may focus on delivering the loads while the dispatcher handles the
                                            rest. In a way, a dispatcher is to driver, what a broker is to a shipper.
                                        </p>
                                        <p><em>To sum up, this is how the cycle is completed. A Shipper contacts a
                                                broker, who is in contact with the dispatcher to assign the loads to a
                                                driver. The dispatcher books &amp; assigns the load to the driver so the
                                                driver can transport the shipment.</em></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section
                    class="elementor-section elementor-top-section elementor-element elementor-element-afa5f90 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="afa5f90" data-element_type="section">
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-6bb8f8c"
                            data-id="6bb8f8c" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-fb959c6 elementor-widget elementor-widget-jet-accordion"
                                    data-id="fb959c6" data-element_type="widget"
                                    data-widget_type="jet-accordion.default">
                                    <div class="elementor-widget-container">
                                        <div class="jet-accordion"
                                            data-settings="{&quot;collapsible&quot;:false,&quot;ajaxTemplate&quot;:false}"
                                            role="tablist">
                                            <div class="jet-accordion__inner">
                                                <div class="jet-accordion__item jet-toggle jet-toggle-move-up-effect ">
                                                    <div id="jet-toggle-control-2631"
                                                        class="jet-toggle__control elementor-menu-anchor"
                                                        data-toggle="1" role="tab"
                                                        aria-controls="jet-toggle-content-2631" aria-expanded="false"
                                                        data-template-id="false">
                                                        <div
                                                            class="jet-toggle__label-icon jet-toggle-icon-position-left">
                                                            <span class="jet-toggle__icon icon-normal jet-tabs-icon"><i
                                                                    aria-hidden="true"
                                                                    class="fa fa-plus"></i></span><span
                                                                class="jet-toggle__icon icon-active jet-tabs-icon"><i
                                                                    aria-hidden="true" class="fa fa-minus"></i></span>
                                                        </div>
                                                        <div class="jet-toggle__label-text">What do you need from me in
                                                            order to start working ?</div>
                                                    </div>
                                                    <div id="jet-toggle-content-2631" class="jet-toggle__content"
                                                        data-toggle="1" role="tabpanel" aria-hidden="true"
                                                        data-template-id="false">
                                                        <div class="jet-toggle__content-inner">
                                                            <p>In order to get started, we need certificate of insurance
                                                                , your W9 &amp; MC number</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="jet-accordion__item jet-toggle jet-toggle-move-up-effect ">
                                                    <div id="jet-toggle-control-2632"
                                                        class="jet-toggle__control elementor-menu-anchor"
                                                        data-toggle="2" role="tab"
                                                        aria-controls="jet-toggle-content-2632" aria-expanded="false"
                                                        data-template-id="false">
                                                        <div
                                                            class="jet-toggle__label-icon jet-toggle-icon-position-left">
                                                            <span class="jet-toggle__icon icon-normal jet-tabs-icon"><i
                                                                    aria-hidden="true"
                                                                    class="fa fa-plus"></i></span><span
                                                                class="jet-toggle__icon icon-active jet-tabs-icon"><i
                                                                    aria-hidden="true" class="fa fa-minus"></i></span>
                                                        </div>
                                                        <div class="jet-toggle__label-text">Do you provide invoicing?
                                                        </div>
                                                    </div>
                                                    <div id="jet-toggle-content-2632" class="jet-toggle__content"
                                                        data-toggle="2" role="tabpanel" aria-hidden="true"
                                                        data-template-id="false">
                                                        <div class="jet-toggle__content-inner">
                                                            <p>Our package includes invoicing in $250 per week</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="jet-accordion__item jet-toggle jet-toggle-move-up-effect ">
                                                    <div id="jet-toggle-control-2633"
                                                        class="jet-toggle__control elementor-menu-anchor"
                                                        data-toggle="3" role="tab"
                                                        aria-controls="jet-toggle-content-2633" aria-expanded="false"
                                                        data-template-id="false">
                                                        <div
                                                            class="jet-toggle__label-icon jet-toggle-icon-position-left">
                                                            <span class="jet-toggle__icon icon-normal jet-tabs-icon"><i
                                                                    aria-hidden="true"
                                                                    class="fa fa-plus"></i></span><span
                                                                class="jet-toggle__icon icon-active jet-tabs-icon"><i
                                                                    aria-hidden="true" class="fa fa-minus"></i></span>
                                                        </div>
                                                        <div class="jet-toggle__label-text">What will you provide me
                                                            with?</div>
                                                    </div>
                                                    <div id="jet-toggle-content-2633" class="jet-toggle__content"
                                                        data-toggle="3" role="tabpanel" aria-hidden="true"
                                                        data-template-id="false">
                                                        <div class="jet-toggle__content-inner">
                                                            <p>We&#8217;ll provide you with all the documents you need
                                                                to get started</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="jet-accordion__item jet-toggle jet-toggle-move-up-effect ">
                                                    <div id="jet-toggle-control-2634"
                                                        class="jet-toggle__control elementor-menu-anchor"
                                                        data-toggle="4" role="tab"
                                                        aria-controls="jet-toggle-content-2634" aria-expanded="false"
                                                        data-template-id="false">
                                                        <div
                                                            class="jet-toggle__label-icon jet-toggle-icon-position-left">
                                                            <span class="jet-toggle__icon icon-normal jet-tabs-icon"><i
                                                                    aria-hidden="true"
                                                                    class="fa fa-plus"></i></span><span
                                                                class="jet-toggle__icon icon-active jet-tabs-icon"><i
                                                                    aria-hidden="true" class="fa fa-minus"></i></span>
                                                        </div>
                                                        <div class="jet-toggle__label-text">How much percent of the
                                                            payload will be mine?</div>
                                                    </div>
                                                    <div id="jet-toggle-content-2634" class="jet-toggle__content"
                                                        data-toggle="4" role="tabpanel" aria-hidden="true"
                                                        data-template-id="false">
                                                        <div class="jet-toggle__content-inner">
                                                            <p>Payload will be 100% yours, with no forced dispatch.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="jet-accordion__item jet-toggle jet-toggle-move-up-effect ">
                                                    <div id="jet-toggle-control-2635"
                                                        class="jet-toggle__control elementor-menu-anchor"
                                                        data-toggle="5" role="tab"
                                                        aria-controls="jet-toggle-content-2635" aria-expanded="false"
                                                        data-template-id="false">
                                                        <div
                                                            class="jet-toggle__label-icon jet-toggle-icon-position-left">
                                                            <span class="jet-toggle__icon icon-normal jet-tabs-icon"><i
                                                                    aria-hidden="true"
                                                                    class="fa fa-plus"></i></span><span
                                                                class="jet-toggle__icon icon-active jet-tabs-icon"><i
                                                                    aria-hidden="true" class="fa fa-minus"></i></span>
                                                        </div>
                                                        <div class="jet-toggle__label-text">Do I need to setup paperwork
                                                            to get started?</div>
                                                    </div>
                                                    <div id="jet-toggle-content-2635" class="jet-toggle__content"
                                                        data-toggle="5" role="tabpanel" aria-hidden="true"
                                                        data-template-id="false">
                                                        <div class="jet-toggle__content-inner">
                                                            <p>No, we&#8217;ll be setting up the paperwork for you. As
                                                                we mentioned earlier, we only need your certificate of
                                                                insurance, your W9 &amp; MC number to get started</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div><!-- .page-content -->

    </article><!-- #post-1502 -->
    </main><!-- #main -->


    </div><!-- #primary -->



    </div>
    </div>

    </div><br><!-- #content -->
    <footer class="footer bg-gold">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="footer__about">
                        <div class="footer__logo">
                            <a href="./index.php"><img src="./img/new_logo.png" alt=""></a>
                        </div>
                        <p>We’re a professional freight dispatching company with proven experience in
                            the
                            field.
                            Our team helps you get the most profitable loads to deliver. We generate
                            high
                            quality
                            and converting leads, providing you all the documents. Making business
                            efficient
                            for both parties.
                        </p>
                        <div class="footer__social">
                            <a href="#"><span class="social_facebook"></span></a>
                            <a href="#"><span class="social_twitter"></span></a>
                            <a href="#"><span class="social_linkedin"></span></a>
                            <a href="#"><span class="social_pinterest"></span></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 offset-lg-1 col-md-6 col-sm-6">
                    <div class="footer__widget">
                        <h5>Quick links</h5>
                        <ul>
                                <li><a href="./about.php">History</a></li>
                                <li><a href="./Dry-van.php">DRY VAN DISPATCH SERVICE</a></li>
                                <li><a href="./Owner-operator.php">OWNER OPERATOR SERVICE</a></li>
                                <li><a href="./Power-only.php">POWER ONLY DISPATCH SERVICE</a></li>
                                <li><a href="./Reefer.php">REEFER DISPATCH SERVICE</a></li>
                                <li><a href="./conditions.php">Terms & Conditions</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="footer__widget">
                        <h5>Contacts</h5>
                        <ul class="address">
                            <li><span class="icon_pin"></span><a href="https://goo.gl/maps/Xs7t8fcVACHGszMh8">978
                                    Hempstead
                                    Tpke,Franklin
                                    Sq,US</a></li>
                            <li><span class="icon_phone"></span><a href="tel:5554280940">
                                    +1-516-246-6566</a></li>
                            <li><span class="icon_mail"></span> <a href="mailto:Info@paramountservices.com"
                                    class="__cf_email__"
                                    data-cfemail="b3daddd5dc9dd0dcdfdcdfdad1f3d4ded2dadf9dd0dcde">Info@paramountservices.com</a>
                            </li>
                        </ul>


                    </div>
                </div>
            </div>
        </div>
        <div class="footer__copyright">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-8">
                        <div class="footer__copyright__text">

                            <p>Copyright &copy;
                                <script data-cfasync="false" src="#"></script>
                                <script>document.write(new Date().getFullYear());</script> All rights
                                reserved
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    
    
    
    <script type='text/javascript' src='./sources/slider-pro-min17.js' id='elementor-webpack-runtime-js'></script>
<script type='text/javascript' src='./sources/slider-pro-min18.js' id='elementor-frontend-modules-js'></script>
<script type='text/javascript' src='./sources/slider-pro-min19.js' id='elementor-waypoints-js'></script>
<script type='text/javascript' src='./sources/slider-pro-min20.js' id='jquery-ui-core-js'></script>
    <script type='text/javascript'
        src='./sources/slider-pro-min21.js'
        id='swiper-js'></script>
    <script type='text/javascript'
        src='./sources/slider-pro-min22.js'
        id='share-link-js'></script>
    <script type='text/javascript'
        src='./sources/slider-pro-min23.js'
        id='elementor-dialog-js'></script>
    <script type='text/javascript' id='elementor-frontend-js-before'>
        var elementorFrontendConfig = { "environmentMode": { "edit": false, "wpPreview": false, "isScriptDebug": false }, "i18n": { "shareOnFacebook": "Share on Facebook", "shareOnTwitter": "Share on Twitter", "pinIt": "Pin it", "download": "Download", "downloadImage": "Download image", "fullscreen": "Fullscreen", "zoom": "Zoom", "share": "Share", "playVideo": "Play Video", "previous": "Previous", "next": "Next", "close": "Close" }, "is_rtl": false, "breakpoints": { "xs": 0, "sm": 480, "md": 768, "lg": 1025, "xl": 1440, "xxl": 1600 }, "responsive": { "breakpoints": { "mobile": { "label": "Mobile", "value": 767, "direction": "max", "is_enabled": true }, "mobile_extra": { "label": "Mobile Extra", "value": 880, "direction": "max", "is_enabled": false }, "tablet": { "label": "Tablet", "value": 1024, "direction": "max", "is_enabled": true }, "tablet_extra": { "label": "Tablet Extra", "value": 1365, "direction": "max", "is_enabled": false }, "laptop": { "label": "Laptop", "value": 1620, "direction": "max", "is_enabled": false }, "widescreen": { "label": "Widescreen", "value": 2400, "direction": "min", "is_enabled": false } } }, "version": "3.2.5", "is_static": false, "experimentalFeatures": { "e_dom_optimization": true, "a11y_improvements": true, "landing-pages": true }, "urls": { "assets": "https:\/\/www.statesdispatchservices.com\/wp-content\/plugins\/elementor\/assets\/" }, "settings": { "page": [], "editorPreferences": [] }, "kit": { "body_background_background": "classic", "active_breakpoints": ["viewport_mobile", "viewport_tablet"], "global_image_lightbox": "yes", "lightbox_enable_counter": "yes", "lightbox_enable_fullscreen": "yes", "lightbox_enable_zoom": "yes", "lightbox_enable_share": "yes", "lightbox_title_src": "title", "lightbox_description_src": "description" }, "post": { "id": 1502, "title": "FAQs%20-%20States%20dispatch%20services", "excerpt": "", "featuredImage": false } };
    </script>
    <script type='text/javascript'
        src='./sources/slider-pro-min24.js'
        id='elementor-frontend-js'></script>
    <script type='text/javascript' id='jet-blocks-js-extra'>
        /* <![CDATA[ */
        var JetHamburgerPanelSettings = { "ajaxurl": "#", "isMobile": "false", "templateApiUrl": "#", "devMode": "false" };
/* ]]> */
    </script>
    <script type='text/javascript'
        src='./sources/jet-blocks.min.js'
        id='jet-blocks-js'></script>
    <script type='text/javascript' id='jet-elements-js-extra'>
        /* <![CDATA[ */
        var jetElements = { "ajaxUrl": "#", "isMobile": "false", "templateApiUrl": "#", "devMode": "false", "messages": { "invalidMail": "Please specify a valid e-mail" } };
/* ]]> */
    </script>
    
    <script type='text/javascript'
        src='./sources/jet-tabs-frontend.min.js'
        id='jet-tabs-frontend-js'></script>
    <script type='text/javascript'
        src='./sources/popperjs.js'
        id='jet-tricks-popperjs-js'></script>
    <script type='text/javascript'
        src='./sources/tippy-bundle.js'
        id='jet-tricks-tippy-bundle-js'></script>
    <script type='text/javascript' id='jet-tricks-frontend-js-extra'>
        /* <![CDATA[ */
        var JetTricksSettings = { "elements_data": { "sections": { "40b7cfdd": { "view_more": false, "particles": "false", "particles_json": null }, "2812cc2b": { "view_more": false, "particles": "false", "particles_json": null }, "488bb29": { "view_more": false, "particles": "false", "particles_json": null }, "33e8353": { "view_more": false, "particles": "false", "particles_json": null }, "ce50500": { "view_more": false, "particles": "false", "particles_json": null }, "afa5f90": { "view_more": false, "particles": "false", "particles_json": null }, "4b1095c0": { "view_more": false, "particles": "false", "particles_json": null }, "3a810e83": { "view_more": false, "particles": "false", "particles_json": null } }, "columns": [], "widgets": { "2c8b58f2": [], "11df0f69": [], "5581dbe7": [], "d3dae9d": [], "25dd79a": [], "d96ea0e": [], "1685673": [], "d264cf9": [], "611acaa": [], "f500e0e": [], "fb959c6": [], "23a8a786": [], "17985c39": [], "244e1b1b": [], "98778be": [], "9905b60": [], "1315c978": [], "290e5a9a": [], "caca841": [], "5edd1a3d": [], "13c7d601": [], "7f4c20b": [], "6d0c148": [], "9214568": [], "43596f2": [], "12f17549": [], "1c165fdb": [] } } };
/* ]]> */
    </script>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="./sources/jquery.js"></script>
    <script>eval(mod_pagespeed_EJfk9gGSrQ);</script>
    <script>eval(mod_pagespeed_vadjZYzCTr);</script>
    <script>eval(mod_pagespeed_QwdlkBSDSA);</script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

    <script async src="./sources/tagmanager.js"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');
    </script>
    <script defer src="./sources/cloudflare.js"
        ></script>
    
</body>

</html>