<!DOCTYPE html>
<html>

<head>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <meta charset="UTF-8">
    <meta name="description" content="Freight-Broker Template">
    <meta name="keywords" content="Freight-Broker, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1'>
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Fracktech: Top-Notch Web Development Company" />
    <meta property="og:description"
        content="Fracktech is a web development company that designs and develops stunning web applications and responsive content for all types businesses." />
    <meta property="og:url" content="https://fracktechnologies.com/" />
    <meta property="og:site_name" content="Fracktech" />
    <meta property="article:modified_time" content="2021-07-12T07:37:07+00:00" />
    <title>Paramount-Dispatch | Carrier</title>
    <style>
        .gold{
            color : #d0ae66 !important;
        }
        .bg-gold{
            background : #d0ae66 !important;
        }
    </style>

    <link rel='stylesheet' id='wpacu-combined-css-head-1' href='./sources/carrier.css' type='text/css' media='all' />

    <script type='text/javascript' src='./sources/jquerymin.js' id='jquery-core-js'></script>

    <link href="./sources/fontsgoogle.css" rel="stylesheet">
    <link href="./sources/fontsgoogle2.css" rel="stylesheet">

    <link rel="stylesheet" href="./sources/bootstrap.css" type="text/css" />

    <link rel='stylesheet' id='google-fonts-1-css' href='./sources/gooleaps.css' type='text/css' media='all' />

</head>

<body>
    <div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
        <div class="offcanvas__search__option">
            <span class="icon_search search-switch"></span>
        </div>
        <div class="offcanvas__logo">
            <a href="./index.php">
                <img src="img/xfooter-logo.png.pagespeed.ic.QfQCJiQvaR.webp" alt="">
            </a>
        </div>
        <div id="mobile-menu-wrap"></div>
        <ul class="offcanvas__widget">
            <li><span class="icon_phone"></span> +1-516-246-6566</li>
            <li><span class="icon_pin"></span> 978 Hempstead Tpke, Franklin Sq, NY, US</li>
        </ul>
        <div class="offcanvas__auth">
            <a href="#"><span class="icon_profile"></span> Register or Sign in</a>
        </div>
        <div class="offcanvas__social">
            <a href="#"><span class="social_facebook"></span></a>
            <a href="#"><span class="social_twitter"></span></a>
            <a href="#"><span class="social_linkedin"></span></a>
            <a href="#"><span class="social_pinterest"></span></a>
        </div>
    </div>

    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 offset-lg-3">
                        <ul class="header__top__widget">
                            <li><span class="icon_phone"></span> +1-516-246-6566</li>
                            <li><span class="icon_pin"></span> 978 Hempstead Tpke, Franklin Sq, NY, US</li>
                        </ul>
                        <div class="header__top__right">
                            <div class="header__top__right__auth">
                                <a href="#"><span class="icon_profile"></span> Register or Sign in</a>
                            </div>
                            <div class="header__top__right__social">
                                <a href="#"><span class="social_facebook"></span></a>
                                <a href="#"><span class="social_twitter"></span></a>
                                <a href="#"><span class="social_linkedin"></span></a>
                                <a href="#"><span class="social_pinterest"></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header__options">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="header__logo">
                            <a href="./index.php"><img src="img/new_logo.png" alt=""></a>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <nav class="header__menu mobile-menu">
                            <ul>
                                <li ><a href="./index.php">Home</a></li>
                                <li><a href="./services.php">Services</a> </li>
                                <li><a href="./about.php">About</a></li>

                                <li><a href="./Pricing.php">Pricing</a></li>
                                <li class="active"><a href="./Carrier.php">Carrier-Setup</a></li>
                                <li><a href="./Faq.php">FAQs</a></li>

                                <li><a href="./contact.php">Contacts</a></li>
                            </ul>
                        </nav>
                    </div>

                </div>
            </div>
            <div class="canvas__open"><i class="fa fa-bars"></i></div>
        </div>

    </header>


    <div id="content" class="site-content ">
        <div data-elementor-type="wp-page" data-elementor-id="1354" class="elementor elementor-1354"
            data-elementor-settings="[]">
            <div class="elementor-section-wrap">
                <section
                    class="elementor-section elementor-top-section elementor-element elementor-element-a12f7fb elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="a12f7fb" data-element_type="section">
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5b6b2bf"
                            data-id="5b6b2bf" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-c3149a8 elementor-widget elementor-widget-heading"
                                    data-id="c3149a8" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container bg-gold">
                                        <h1 class="elementor-heading-title elementor-size-default ">Carrier set-up</h1>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-7e36348 elementor-widget elementor-widget-contact-form-7"
                                    data-id="7e36348" data-element_type="widget"
                                    data-widget_type="contact-form-7.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-contact-form-7 jet-elements">
                                            <div role="form" class="wpcf7" id="wpcf7-f1856-p1354-o1" lang="en-US"
                                                dir="ltr">
                                                <div class="screen-reader-response">
                                                    <p role="status" aria-live="polite" aria-atomic="true"></p>
                                                    <ul></ul>
                                                </div>
                                                <form action="#" method="post"
                                                    class="wpcf7-form init" novalidate="novalidate" data-status="init">
                                                    <div style="display: none;">
                                                        <input type="hidden" name="_wpcf7" value="1856" />
                                                        <input type="hidden" name="_wpcf7_version" value="5.4.1" />
                                                        <input type="hidden" name="_wpcf7_locale" value="en_US" />
                                                        <input type="hidden" name="_wpcf7_unit_tag"
                                                            value="wpcf7-f1856-p1354-o1" />
                                                        <input type="hidden" name="_wpcf7_container_post"
                                                            value="1354" />
                                                        <input type="hidden" name="_wpcf7_posted_data_hash" value="" />
                                                    </div>

                                                    <!-- CF7MSM -->
                                                    <div style='display:none;'><input type="hidden"
                                                            name="_cf7msm_multistep_tag"
                                                            value="#"
                                                            class="wpcf7-form-control cf7msm-multistep wpcf7-multistep" /><input
                                                            type="hidden" name="cf7msm-no-ss" value="" /></div>
                                                    <!-- End CF7MSM -->

                                                    <p><label> Mc # / DOT / Interstate permit<br />
                                                            <span
                                                                class="wpcf7-form-control-wrap McDOTInterstatepermit"><input
                                                                    type="text" name="McDOTInterstatepermit" value=""
                                                                    size="40"
                                                                    class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required"
                                                                    aria-required="true" aria-invalid="false" /></span>
                                                        </label></p>
                                                    <p><label> IEM / SSN /W9<br />
                                                            <span class="wpcf7-form-control-wrap IEMSSNW9"><input
                                                                    type="text" name="IEMSSNW9" value="" size="40"
                                                                    class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required"
                                                                    aria-required="true" aria-invalid="false" /></span>
                                                        </label></p>
                                                    <p><label> Phone/mobile number<br />
                                                            <span class="wpcf7-form-control-wrap phonenumber"><input
                                                                    type="tel" name="phonenumber" value="" size="40"
                                                                    class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel"
                                                                    aria-required="true" aria-invalid="false" /></span>
                                                        </label></p>
                                                    <p><label> Address<br />
                                                            <span class="wpcf7-form-control-wrap address"><textarea
                                                                    name="address" cols="40" rows="10"
                                                                    class="wpcf7-form-control wpcf7-textarea wpcf7-validates-as-required"
                                                                    aria-required="true"
                                                                    aria-invalid="false"></textarea></span> </label></p>
                                                    <p><label> Full name<br />
                                                            <span class="wpcf7-form-control-wrap your-name"><input
                                                                    type="text" name="your-name" value="" size="40"
                                                                    class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required"
                                                                    aria-required="true" aria-invalid="false" /></span>
                                                        </label></p>
                                                    <p>Select state</p>
                                                    <p><span class="wpcf7-form-control-wrap stateselect"><select
                                                                name="stateselect"
                                                                class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required"
                                                                aria-required="true" aria-invalid="false">
                                                                <option value="">---</option>
                                                                <option value="AK">AK</option>
                                                                <option value="AL">AL</option>
                                                                <option value="AR">AR</option>
                                                                <option value="AZ">AZ</option>
                                                                <option value="CA">CA</option>
                                                                <option value="CO">CO</option>
                                                                <option value="CT">CT</option>
                                                                <option value="DC">DC</option>
                                                                <option value="DE">DE</option>
                                                                <option value="FL">FL</option>
                                                                <option value="GA">GA</option>
                                                                <option value="HI">HI</option>
                                                                <option value="IA">IA</option>
                                                                <option value="ID">ID</option>
                                                                <option value="IL">IL</option>
                                                                <option value="IN">IN</option>
                                                                <option value="KS">KS</option>
                                                                <option value="KY">KY</option>
                                                                <option value="LA">LA</option>
                                                                <option value="MA">MA</option>
                                                                <option value="MD">MD</option>
                                                                <option value="ME">ME</option>
                                                                <option value="MI">MI</option>
                                                                <option value="MN">MN</option>
                                                                <option value="MO">MO</option>
                                                                <option value="MS">MS</option>
                                                                <option value="MT">MT</option>
                                                                <option value="NC">NC</option>
                                                                <option value="ND">ND</option>
                                                                <option value="NE">NE</option>
                                                                <option value="NH">NH</option>
                                                                <option value="NJ">NJ</option>
                                                                <option value="NM">NM</option>
                                                                <option value="NV">NV</option>
                                                                <option value="NY">NY</option>
                                                                <option value="OH">OH</option>
                                                                <option value="OK">OK</option>
                                                                <option value="OR">OR</option>
                                                                <option value="PA">PA</option>
                                                                <option value="RI">RI</option>
                                                                <option value="SC">SC</option>
                                                                <option value="SD">SD</option>
                                                                <option value="TN">TN</option>
                                                                <option value="TX">TX</option>
                                                                <option value="UT">UT</option>
                                                                <option value="VA">VA</option>
                                                                <option value="VT">VT</option>
                                                                <option value="WA">WA</option>
                                                                <option value="WI">WI</option>
                                                                <option value="WV">WV</option>
                                                                <option value="WY">WY</option>
                                                            </select></span></p>
                                                    <p><label> Your email<br />
                                                            <span class="wpcf7-form-control-wrap your-email"><input
                                                                    type="email" name="your-email" value="" size="40"
                                                                    class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email"
                                                                    aria-required="true" aria-invalid="false" /></span>
                                                        </label></p>
                                                    <p><label> Insurance company<br />
                                                            <span
                                                                class="wpcf7-form-control-wrap Insurancecompany"><input
                                                                    type="text" name="Insurancecompany" value=""
                                                                    size="40"
                                                                    class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required"
                                                                    aria-required="true" aria-invalid="false" /></span>
                                                        </label></p>
                                                    <p><label> Insurance contact name<br />
                                                            <span
                                                                class="wpcf7-form-control-wrap Insurancecontactname"><input
                                                                    type="text" name="Insurancecontactname" value=""
                                                                    size="40"
                                                                    class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required"
                                                                    aria-required="true" aria-invalid="false" /></span>
                                                        </label></p>
                                                    <p><label> Insurance phone number<br />
                                                            <span
                                                                class="wpcf7-form-control-wrap Insurancephonenumber"><input
                                                                    type="tel" name="Insurancephonenumber" value=""
                                                                    size="40"
                                                                    class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel"
                                                                    aria-required="true" aria-invalid="false" /></span>
                                                        </label></p>
                                                    <p><label> Factoring company name<br />
                                                            <span
                                                                class="wpcf7-form-control-wrap Nameofthefactory"><input
                                                                    type="text" name="Nameofthefactory" value=""
                                                                    size="40"
                                                                    class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required"
                                                                    aria-required="true" aria-invalid="false" /></span>
                                                        </label></p>
                                                    <p><label> Number of drivers<br />
                                                            <span class="wpcf7-form-control-wrap Numberofdrivers"><input
                                                                    type="tel" name="Numberofdrivers" value="" size="40"
                                                                    class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel"
                                                                    aria-required="true" aria-invalid="false" /></span>
                                                        </label></p>
                                                    <p><label> Number of trucks<br />
                                                            <span class="wpcf7-form-control-wrap Numberoftrucks"><input
                                                                    type="tel" name="Numberoftrucks" value="" size="40"
                                                                    class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel"
                                                                    aria-required="true" aria-invalid="false" /></span>
                                                        </label></p>
                                                    <p>Type of equipment<br />
                                                        <span class="wpcf7-form-control-wrap equipmentselect"><select
                                                                name="equipmentselect"
                                                                class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required"
                                                                aria-required="true" aria-invalid="false">
                                                                <option value="">---</option>
                                                                <option value="Dry Van">Dry Van</option>
                                                                <option value="Reefer">Reefer</option>
                                                                <option value="Flatbed">Flatbed</option>
                                                                <option value="Step deck">Step deck</option>
                                                                <option value="Other">Other</option>
                                                            </select></span>
                                                    </p>
                                                    <p><label> States for driving<br />
                                                            <span
                                                                class="wpcf7-form-control-wrap Nameofthestatesyoudprefertodrivein"><input
                                                                    type="text"
                                                                    name="Nameofthestatesyoudprefertodrivein" value=""
                                                                    size="40"
                                                                    class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required"
                                                                    aria-required="true" aria-invalid="false" /></span>
                                                        </label></p>
                                                    <p><label> Choose Payment Plan<br />
                                                            <span class="wpcf7-form-control-wrap howtopay"><select
                                                                    name="howtopay"
                                                                    class="wpcf7-form-control wpcf7-select wpcf7-validates-as-required"
                                                                    aria-required="true" aria-invalid="false">
                                                                    <option value="">---</option>
                                                                    <option value="$999.00/Month">$999.00/Month</option>
                                                                    <option value="$300.00/Week">$300.00/Week</option>
                                                                    <option value="6% Weekly (Total Gross)">6% Weekly
                                                                        (Total Gross)</option>
                                                                </select></span></p>
                                                    <p><input type="submit" value="Submit"
                                                            class="wpcf7-form-control wpcf7-submit bg-gold" /></p>
                                                    <div class="wpcf7-response-output" aria-hidden="true"></div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>

    </div><!-- #content -->
    <footer class="footer bg-gold">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="footer__about">
                        <div class="footer__logo">
                            <a href="./index.php"><img src="./img/new_logo.png" alt=""></a>
                        </div>
                        <p>We’re a professional freight dispatching company with proven experience in
                            the
                            field.
                            Our team helps you get the most profitable loads to deliver. We generate
                            high
                            quality
                            and converting leads, providing you all the documents. Making business
                            efficient
                            for both parties.
                        </p>
                        <div class="footer__social">
                            <a href="#"><span class="social_facebook"></span></a>
                            <a href="#"><span class="social_twitter"></span></a>
                            <a href="#"><span class="social_linkedin"></span></a>
                            <a href="#"><span class="social_pinterest"></span></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 offset-lg-1 col-md-6 col-sm-6">
                    <div class="footer__widget">
                        <h5>Quick links</h5>
                        <ul>
                                <li><a href="./about.php">History</a></li>
                                <li><a href="./Dry-van.php">DRY VAN DISPATCH SERVICE</a></li>
                                <li><a href="./Owner-operator.php">OWNER OPERATOR SERVICE</a></li>
                                <li><a href="./Power-only.php">POWER ONLY DISPATCH SERVICE</a></li>
                                <li><a href="./Reefer.php">REEFER DISPATCH SERVICE</a></li>
                                <li><a href="./conditions.php">Terms & Conditions</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="footer__widget">
                        <h5>Contacts</h5>
                        <ul class="address">
                            <li><span class="icon_pin"></span><a href="https://goo.gl/maps/Xs7t8fcVACHGszMh8">978
                                    Hempstead
                                    Tpke,Franklin
                                    Sq,US</a></li>
                            <li><span class="icon_phone"></span><a href="tel:5554280940">
                                    +1-516-246-6566</a></li>
                            <li><span class="icon_mail"></span> <a href="mailto:Info@paramountservices.com"
                                    class="__cf_email__"
                                    data-cfemail="b3daddd5dc9dd0dcdfdcdfdad1f3d4ded2dadf9dd0dcde">Info@paramountservices.com</a>
                            </li>
                        </ul>


                    </div>
                </div>
            </div>
        </div>
        <div class="footer__copyright">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-8">
                        <div class="footer__copyright__text">

                            <p>Copyright &copy;
                                <script data-cfasync="false" src="#"></script>
                                <script>document.write(new Date().getFullYear());</script> All rights
                                reserved
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

    <script async src="./sources/tagmanager.js"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');
       

    </script>
    <script defer src="./sources/cloudflare.js"></script>

</body>

</html>