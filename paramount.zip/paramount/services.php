<!DOCTYPE html>
<html>

<head>

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <meta charset="UTF-8">
    <meta name="description" content="Freight-Broker Template">
    <meta name="keywords" content="Freight-Broker, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1'>
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Fracktech: Top-Notch Web Development Company" />
    <meta property="og:description"
        content="Fracktech is a web development company that designs and develops stunning web applications and responsive content for all types businesses." />
    <meta property="og:url" content="https://fracktechnologies.com/" />
    <meta property="og:site_name" content="Fracktech" />
    <meta property="article:modified_time" content="2021-07-12T07:37:07+00:00" />
    <title>Paramount-Dispatch | Services</title>
    <style>
        .gold{
            color : #d0ae66 !important;
        }
        .bg-gold{
            background : #d0ae66 !important;
        }
    </style>

    <link rel='stylesheet' id='wpacu-combined-css-head-1' href='./sources/serv.css' type='text/css' media='all' />

    <script type='text/javascript' src='./sources/jquerymin.js' id='jquery-core-js'></script>


    <link href="./sources/fontsgoogle.css" rel="stylesheet">
    <link href="./sources/fontsgoogle2.css" rel="stylesheet">

    <link rel="stylesheet" href="./sources/bootstrap.css" type="text/css" />

    <link rel='stylesheet' id='google-fonts-1-css' href='./sources/gooleaps.css' type='text/css' media='all' />
</head>

<body>
    

    <div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
        <div class="offcanvas__search__option">
            <span class="icon_search search-switch"></span>
        </div>
        <div class="offcanvas__logo">
            <a href="./index.php">
                <img src="img/xfooter-logo.png.pagespeed.ic.QfQCJiQvaR.webp" alt="">
            </a>
        </div>
        <div id="mobile-menu-wrap"></div>
        <ul class="offcanvas__widget">
            <li><span class="icon_phone"></span> +1-516-246-6566</li>
            <li><span class="icon_pin"></span> 978 Hempstead Tpke, Franklin Sq, NY, US</li>
        </ul>
        <div class="offcanvas__auth">
            <a href="#"><span class="icon_profile"></span> Register or Sign in</a>
        </div>
        <div class="offcanvas__social">
            <a href="#"><span class="social_facebook"></span></a>
            <a href="#"><span class="social_twitter"></span></a>
            <a href="#"><span class="social_linkedin"></span></a>
            <a href="#"><span class="social_pinterest"></span></a>
        </div>
    </div>


    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 offset-lg-3">
                        <ul class="header__top__widget">
                            <li><span class="icon_phone"></span> +1-516-246-6566</li>
                            <li><span class="icon_pin"></span> 978 Hempstead Tpke, Franklin Sq, NY, US</li>
                        </ul>
                        <div class="header__top__right">
                            <div class="header__top__right__auth">
                                <a href="#"><span class="icon_profile"></span> Register or Sign in</a>
                            </div>
                            <div class="header__top__right__social">
                                <a href="#"><span class="social_facebook"></span></a>
                                <a href="#"><span class="social_twitter"></span></a>
                                <a href="#"><span class="social_linkedin"></span></a>
                                <a href="#"><span class="social_pinterest"></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header__options">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="header__logo">
                            <a href="./index.php"><img src="img/new_logo.png" alt=""></a>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <nav class="header__menu mobile-menu">
                            <ul>
                                <li ><a href="./index.php">Home</a></li>
                                <li class="active"><a href="./services.php">Services</a> </li>
                                <li><a href="./about.php">About</a></li>

                                <li><a href="./Pricing.php">Pricing</a></li>
                                <li><a href="./Carrier.php">Carrier-Setup</a></li>
                                <li><a href="./Faq.php">FAQs</a></li>

                                <li><a href="./contact.php">Contacts</a></li>
                            </ul>
                        </nav>
                    </div>
                    
                </div>
            </div>
            <div class="canvas__open"><i class="fa fa-bars"></i></div>
        </div>
    </header>


    <div id="content" class="site-content ">
        <div data-elementor-type="wp-page" data-elementor-id="554" class="elementor elementor-554"
            data-elementor-settings="[]">
            <div class="elementor-section-wrap">
                <section
                    class="elementor-section elementor-top-section elementor-element elementor-element-487012ce elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="487012ce" data-element_type="section"
                    data-settings="{&quot;background_background&quot;:&quot;classic&quot;}">
                    <div class="elementor-background-overlay"></div>
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-16e71d80"
                            data-id="16e71d80" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-7b44c146 elementor-widget elementor-widget-heading"
                                    data-id="7b44c146" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">Services</h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-35c728c2 elementor-widget-divider--view-line elementor-widget elementor-widget-divider"
                                    data-id="35c728c2" data-element_type="widget" data-widget_type="divider.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-divider">
                                            <span class="elementor-divider-separator">
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-47da6d9 elementor-widget elementor-widget-text-editor"
                                    data-id="47da6d9" data-element_type="widget" data-widget_type="text-editor.default">
                                    <div class="elementor-widget-container">
                                        <p style="color:#E7E9EB;">Paramount Dispatch Services all kinds of truck dispatch services, at very
                                            reasonable pricing</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section
                    class="elementor-section elementor-top-section elementor-element elementor-element-2765f84b elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="2765f84b" data-element_type="section">
                    <div class="elementor-container elementor-column-gap-extended">
                        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-7e7b5859 elementor-invisible"
                            data-id="7e7b5859" data-element_type="column"
                            data-settings="{&quot;animation&quot;:&quot;zoomIn&quot;,&quot;animation_delay&quot;:400}">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-3fa16fda elementor-widget elementor-widget-jet-animated-box"
                                    data-id="3fa16fda" data-element_type="widget"
                                    data-widget_type="jet-animated-box.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-jet-animated-box jet-elements">
                                            <div id="jet-animated-box-3fa16fda"
                                                class="jet-animated-box jet-box-effect-10"
                                                data-settings='{"widgetId":"3fa16fda","switchEventType":"hover","paperFoldDirection":"left","slideOutDirection":"left"}'>
                                                <div id="jet-animated-box__front-3fa16fda"
                                                    class="jet-animated-box__front">
                                                    <div class="jet-animated-box__inner">
                                                        <div
                                                            class="jet-animated-box__icon jet-animated-box__icon--front">
                                                            <div class="jet-animated-box-icon-inner"><span
                                                                    class="jet-elements-icon"><i aria-hidden="true"
                                                                        class="fa fa-cogs"></i></span>
                                                            </div>
                                                        </div>
                                                        <div class="jet-animated-box__content">
                                                            <h3
                                                                class="jet-animated-box__title jet-animated-box__title--front">
                                                                Dry van dispatch services</h3>
                                                            <p
                                                                class="jet-animated-box__description jet-animated-box__description--front">
                                                                Paramount Dispatch Services offers Dry van services.
                                                                Heavy machinery & any equipment? Dry van is your
                                                                answer</p>
                                                        </div>
                                                    </div>
                                                    <div class="jet-animated-box__overlay"></div>
                                                </div>
                                                <div id="jet-animated-box__back-3fa16fda"
                                                    class="jet-animated-box__back">
                                                    <div class="jet-animated-box__inner">
                                                        <div
                                                            class="jet-animated-box__icon jet-animated-box__icon--back">
                                                            <div class="jet-animated-box-icon-inner"><span
                                                                    class="jet-elements-icon"><i aria-hidden="true"
                                                                        class="fasnc-icon-outline travel_hotel"></i></span>
                                                            </div>
                                                        </div>
                                                        <div class="jet-animated-box__content">
                                                            <h3
                                                                class="jet-animated-box__title jet-animated-box__title--back">
                                                                More info</h3>
                                                            <p
                                                                class="jet-animated-box__description jet-animated-box__description--back">
                                                                Paramount Dispatch Services offers Dry van services.
                                                                Heavy machinery & any equipment? Dry van is your
                                                                answer</p><a
                                                                class="elementor-button elementor-size-md jet-animated-box__button jet-animated-box__button--back jet-animated-box__button--icon-"
                                                                href="Dry-van.php"><span
                                                                    class="jet-animated-box__button-text">Learn
                                                                    More</span></a>

                                                        </div>
                                                    </div>
                                                    <div class="jet-animated-box__overlay"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-7bbe83db elementor-invisible"
                            data-id="7bbe83db" data-element_type="column"
                            data-settings="{&quot;animation&quot;:&quot;zoomIn&quot;,&quot;animation_delay&quot;:400}">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-5d08a13c elementor-widget elementor-widget-jet-animated-box"
                                    data-id="5d08a13c" data-element_type="widget"
                                    data-widget_type="jet-animated-box.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-jet-animated-box jet-elements">
                                            <div id="jet-animated-box-5d08a13c"
                                                class="jet-animated-box jet-box-effect-10"
                                                data-settings='{"widgetId":"5d08a13c","switchEventType":"hover","paperFoldDirection":"left","slideOutDirection":"left"}'>
                                                <div id="jet-animated-box__front-5d08a13c"
                                                    class="jet-animated-box__front">
                                                    <div class="jet-animated-box__inner">
                                                        <div
                                                            class="jet-animated-box__icon jet-animated-box__icon--front">
                                                            <div class="jet-animated-box-icon-inner"><span
                                                                    class="jet-elements-icon"><i aria-hidden="true"
                                                                        class="fa fa-truck"></i></span></div>
                                                        </div>
                                                        <div class="jet-animated-box__content">
                                                            <h3
                                                                class="jet-animated-box__title jet-animated-box__title--front">
                                                                Power only dispatch services</h3>
                                                            <p
                                                                class="jet-animated-box__description jet-animated-box__description--front">
                                                                Power only dispatch helps you save costs and be more
                                                                efficient by hooking behind an existing carrier.</p>
                                                        </div>
                                                    </div>
                                                    <div class="jet-animated-box__overlay"></div>
                                                </div>
                                                <div id="jet-animated-box__back-5d08a13c"
                                                    class="jet-animated-box__back">
                                                    <div class="jet-animated-box__inner">
                                                        <div
                                                            class="jet-animated-box__icon jet-animated-box__icon--back">
                                                            <div class="jet-animated-box-icon-inner"><span
                                                                    class="jet-elements-icon"><i aria-hidden="true"
                                                                        class="fasnc-icon-outline ui-1_settings"></i></span>
                                                            </div>
                                                        </div>
                                                        <div class="jet-animated-box__content">
                                                            <h3
                                                                class="jet-animated-box__title jet-animated-box__title--back">
                                                                More info</h3>
                                                            <p
                                                                class="jet-animated-box__description jet-animated-box__description--back">
                                                                Power only dispatch helps you save costs and be more
                                                                efficient by hooking behind an existing carrier.</p>
                                                            <a class="elementor-button elementor-size-md jet-animated-box__button jet-animated-box__button--back jet-animated-box__button--icon-"
                                                                href="Power-only.php"><span
                                                                    class="jet-animated-box__button-text">Learn
                                                                    More</span></a>

                                                        </div>
                                                    </div>
                                                    <div class="jet-animated-box__overlay"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-78248e68 elementor-invisible"
                            data-id="78248e68" data-element_type="column"
                            data-settings="{&quot;animation&quot;:&quot;zoomIn&quot;,&quot;animation_delay&quot;:1200}">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-2d82de14 elementor-widget elementor-widget-jet-animated-box"
                                    data-id="2d82de14" data-element_type="widget"
                                    data-widget_type="jet-animated-box.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-jet-animated-box jet-elements">
                                            <div id="jet-animated-box-2d82de14"
                                                class="jet-animated-box jet-box-effect-10"
                                                data-settings='{"widgetId":"2d82de14","switchEventType":"hover","paperFoldDirection":"left","slideOutDirection":"left"}'>
                                                <div id="jet-animated-box__front-2d82de14"
                                                    class="jet-animated-box__front">
                                                    <div class="jet-animated-box__inner">
                                                        <div
                                                            class="jet-animated-box__icon jet-animated-box__icon--front">
                                                            <div class="jet-animated-box-icon-inner"><span
                                                                    class="jet-elements-icon"><svg xmlns="#"
                                                                        xmlns:xlink="#" id="Layer_2"
                                                                        style="enable-background:new 0 0 1000 1000;"
                                                                        viewBox="0 0 1000 1000" xml:space="preserve">
                                                                        <path
                                                                            d="M835.039,367.227H369.611c-8.882,0-16.082,7.201-16.082,16.082v5.18  c0,6.856,4.298,12.694,10.34,15.008v158.045h-19.11v-111.31c0-0.027,0.004-0.052,0.004-0.079v-14.744  c0-4.633-4.279-8.082-8.807-7.098l-26.509,5.763c-2.654,0.577-4.765,2.587-5.471,5.21l-1.402,5.208h-20.715  c-10.87,0-21.13,5.03-27.79,13.62l-29.69,38.29c-5.17,6.65-12.55,11.24-20.8,12.91l-19.13,3.89c-12.36,2.5-21.77,12.56-23.47,25.05  l-3.4,25.09c-5.17,2.66-8.7,8.06-8.7,14.28v5.18c0,8.88,7.2,16.08,16.08,16.08h21.54c3.61,19.29,20.53,33.89,40.86,33.89  c20.33,0,37.26-14.6,40.87-33.89h120.89c3.61,19.29,20.54,33.89,40.87,33.89c20.329,0,37.26-14.6,40.87-33.89h13.91  c3.61,19.29,20.53,33.89,40.87,33.89c20.33,0,37.25-14.6,40.86-33.89h81.99c3.61,19.29,20.53,33.89,40.86,33.89  c20.34,0,37.26-14.6,40.87-33.89h13.91c3.61,19.29,20.54,33.89,40.87,33.89c20.33,0,37.26-14.6,40.87-33.89h9.17  c8.15,0,14.89-6.07,15.93-13.94h0.15v-2.14v-5.18V388.527c0-0.013,0.002-0.025,0.002-0.038v-5.18  C851.121,374.427,843.92,367.227,835.039,367.227z M179.979,561.543c-1.01,0.98-2.17,1.54-3.39,1.54c-1.23,0-2.39-0.56-3.4-1.54  c-2.22-2.16-3.73-6.37-3.73-11.21c0-7.04,3.19-12.75,7.13-12.75c3.93,0,7.12,5.71,7.12,12.75  C183.709,555.173,182.199,559.383,179.979,561.543z M245.859,598.883c-3.02,7.24-10.17,12.34-18.5,12.34  c-8.33,0-15.48-5.1-18.5-12.34c-0.99-2.36-1.53-4.96-1.53-7.69c0-2.18,0.35-4.28,1-6.25c2.63-8,10.16-13.78,19.03-13.78  c8.87,0,16.4,5.78,19.03,13.78c0.65,1.97,1,4.07,1,6.25C247.389,593.923,246.849,596.523,245.859,598.883z M327.759,509.863  c0,3.73-3.02,6.75-6.75,6.75h-61.75c-1.9,0-3.68-0.83-4.99-2.21c-2.34-2.48-5.02-4.62-7.94-6.36c-3.45-2.05-4.27-6.7-1.8-9.88  l22.97-29.63c3.42-4.41,8.79-7.04,14.36-7.04h39.15c3.73,0,6.75,3.02,6.75,6.75V509.863z M448.479,598.883  c-3.01,7.24-10.16,12.34-18.49,12.34c-8.33,0-15.48-5.1-18.49-12.34c-0.99-2.36-1.54-4.96-1.54-7.69c0-2.18,0.35-4.28,1-6.25  c2.63-8,10.16-13.78,19.03-13.78c8.87,0,16.4,5.78,19.03,13.78c0.65,1.97,1,4.07,1,6.25  C450.019,593.923,449.469,596.523,448.479,598.883z M544.129,598.883c-3.02,7.24-10.17,12.34-18.49,12.34  c-8.33,0-15.48-5.1-18.5-12.34c-0.99-2.36-1.54-4.96-1.54-7.69c0-2.18,0.35-4.28,1-6.25c2.63-8,10.17-13.78,19.04-13.78  c8.86,0,16.4,5.78,19.03,13.78c0.65,1.97,1,4.07,1,6.25C545.669,593.923,545.119,596.523,544.129,598.883z M707.849,598.883  c-3.02,7.24-10.17,12.34-18.5,12.34c-8.32,0-15.47-5.1-18.49-12.34c-0.99-2.36-1.54-4.96-1.54-7.69c0-2.18,0.35-4.28,1-6.25  c2.63-8,10.171-13.78,19.03-13.78c8.87,0,16.41,5.78,19.04,13.78c0.65,1.97,1,4.07,1,6.25  C709.389,593.923,708.839,596.523,707.849,598.883z M803.499,598.883c-3.02,7.24-10.17,12.34-18.5,12.34  c-8.33,0-15.48-5.1-18.5-12.34c-0.99-2.36-1.53-4.96-1.53-7.69c0-2.18,0.35-4.28,1-6.25c2.63-8,10.16-13.78,19.03-13.78  c8.87,0,16.4,5.78,19.03,13.78c0.65,1.97,1,4.07,1,6.25C805.029,593.923,804.489,596.523,803.499,598.883z M799.737,548.533H415.25  c-4.694,0-8.5-3.805-8.5-8.5c0-4.694,3.806-8.5,8.5-8.5h384.487c4.694,0,8.5,3.806,8.5,8.5  C808.237,544.727,804.432,548.533,799.737,548.533z M799.737,439.313H415.25c-4.694,0-8.5-3.806-8.5-8.5c0-4.694,3.806-8.5,8.5-8.5  h384.487c4.694,0,8.5,3.806,8.5,8.5C808.237,435.508,804.432,439.313,799.737,439.313z"
                                                                            style="fill:#231F20;"></path>
                                                                    </svg></span></div>
                                                        </div>
                                                        <div class="jet-animated-box__content">
                                                            <h3
                                                                class="jet-animated-box__title jet-animated-box__title--front">
                                                                Owner operator dispatch services</h3>
                                                            <p
                                                                class="jet-animated-box__description jet-animated-box__description--front">
                                                                Owner-operaots have their own equipement and trucks,
                                                                and may drive their own trucks or hire them out.</p>
                                                        </div>
                                                    </div>
                                                    <div class="jet-animated-box__overlay"></div>
                                                </div>
                                                <div id="jet-animated-box__back-2d82de14"
                                                    class="jet-animated-box__back">
                                                    <div class="jet-animated-box__inner">
                                                        <div
                                                            class="jet-animated-box__icon jet-animated-box__icon--back">
                                                            <div class="jet-animated-box-icon-inner"><span
                                                                    class="jet-elements-icon"><i aria-hidden="true"
                                                                        class="fasnc-icon-outline ui-2_tile-55"></i></span>
                                                            </div>
                                                        </div>
                                                        <div class="jet-animated-box__content">
                                                            <h3
                                                                class="jet-animated-box__title jet-animated-box__title--back">
                                                                More info</h3>
                                                            <p
                                                                class="jet-animated-box__description jet-animated-box__description--back">
                                                                Owner-operator have their own equipement and trucks,
                                                                and may drive their own trucks or hire them out.</p>
                                                            <a class="elementor-button elementor-size-md jet-animated-box__button jet-animated-box__button--back jet-animated-box__button--icon-"
                                                                href="Owner-operator.php"><span
                                                                    class="jet-animated-box__button-text">Learn
                                                                    More</span></a>

                                                        </div>
                                                    </div>
                                                    <div class="jet-animated-box__overlay"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-7d6996bd elementor-invisible"
                            data-id="7d6996bd" data-element_type="column"
                            data-settings="{&quot;animation&quot;:&quot;zoomIn&quot;,&quot;animation_delay&quot;:1600}">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-afaacaf elementor-widget elementor-widget-jet-animated-box"
                                    data-id="afaacaf" data-element_type="widget"
                                    data-widget_type="jet-animated-box.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-jet-animated-box jet-elements">
                                            <div id="jet-animated-box-afaacaf"
                                                class="jet-animated-box jet-box-effect-10"
                                                data-settings='{"widgetId":"afaacaf","switchEventType":"hover","paperFoldDirection":"left","slideOutDirection":"left"}'>
                                                <div id="jet-animated-box__front-afaacaf"
                                                    class="jet-animated-box__front">
                                                    <div class="jet-animated-box__inner">
                                                        <div
                                                            class="jet-animated-box__icon jet-animated-box__icon--front">
                                                            <div class="jet-animated-box-icon-inner"><span
                                                                    class="jet-elements-icon"><i aria-hidden="true"
                                                                        class="fa fa-globe"></i></span>
                                                            </div>
                                                        </div>
                                                        <div class="jet-animated-box__content">
                                                            <h3
                                                                class="jet-animated-box__title jet-animated-box__title--front">
                                                                Flatbed truck dispatch services</h3>
                                                            <p
                                                                class="jet-animated-box__description jet-animated-box__description--front">
                                                                Flatbed dispatch services help transport goods that
                                                                are not vulnerable to weather conditions</p>
                                                        </div>
                                                    </div>
                                                    <div class="jet-animated-box__overlay"></div>
                                                </div>
                                                <div id="jet-animated-box__back-afaacaf" class="jet-animated-box__back">
                                                    <div class="jet-animated-box__inner">
                                                        <div
                                                            class="jet-animated-box__icon jet-animated-box__icon--back">
                                                            <div class="jet-animated-box-icon-inner"><span
                                                                    class="jet-elements-icon"><i aria-hidden="true"
                                                                        class="fasnc-icon-outline users-2_home"></i></span>
                                                            </div>
                                                        </div>
                                                        <div class="jet-animated-box__content">
                                                            <h3
                                                                class="jet-animated-box__title jet-animated-box__title--back">
                                                                More info</h3>
                                                            <p
                                                                class="jet-animated-box__description jet-animated-box__description--back">
                                                                Flatbed dispatch services help transport goods that
                                                                are not vulnerable to weather conditions</p><a
                                                                class="elementor-button elementor-size-md jet-animated-box__button jet-animated-box__button--back jet-animated-box__button--icon-"
                                                                href="#"><span
                                                                    class="jet-animated-box__button-text">Learn
                                                                    More</span></a>

                                                        </div>
                                                    </div>
                                                    <div class="jet-animated-box__overlay"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section
                    class="elementor-section elementor-top-section elementor-element elementor-element-26efbf5d elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="26efbf5d" data-element_type="section">
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-58c7fc51"
                            data-id="58c7fc51" data-element_type="column">
                            <div class="elementor-widget-wrap">
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-29e38fa7 elementor-invisible"
                            data-id="29e38fa7" data-element_type="column"
                            data-settings="{&quot;animation&quot;:&quot;zoomIn&quot;,&quot;animation_delay&quot;:400}">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-6ecfa968 elementor-widget elementor-widget-jet-animated-box"
                                    data-id="6ecfa968" data-element_type="widget"
                                    data-widget_type="jet-animated-box.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-jet-animated-box jet-elements">
                                            <div id="jet-animated-box-6ecfa968"
                                                class="jet-animated-box jet-box-effect-10"
                                                data-settings='{"widgetId":"6ecfa968","switchEventType":"hover","paperFoldDirection":"left","slideOutDirection":"left"}'>
                                                <div id="jet-animated-box__front-6ecfa968"
                                                    class="jet-animated-box__front">
                                                    <div class="jet-animated-box__inner">
                                                        <div
                                                            class="jet-animated-box__icon jet-animated-box__icon--front">
                                                            <div class="jet-animated-box-icon-inner"><span
                                                                    class="jet-elements-icon"><svg xmlns="#" fill="none"
                                                                        height="24" stroke="currentColor"
                                                                        stroke-linecap="round" stroke-linejoin="round"
                                                                        stroke-width="2" viewBox="0 0 24 24" width="24">
                                                                        <rect height="13" width="15" x="1" y="3">
                                                                        </rect>
                                                                        <polygon
                                                                            points="16 8 20 8 23 11 23 16 16 16 16 8">
                                                                        </polygon>
                                                                        <circle cx="5.5" cy="18.5" r="2.5"></circle>
                                                                        <circle cx="18.5" cy="18.5" r="2.5">
                                                                        </circle>
                                                                    </svg></span></div>
                                                        </div>
                                                        <div class="jet-animated-box__content">
                                                            <h3
                                                                class="jet-animated-box__title jet-animated-box__title--front">
                                                                Independent truck dispatch services</h3>
                                                            <p
                                                                class="jet-animated-box__description jet-animated-box__description--front">
                                                                With independent dispatch services, cut the
                                                                'middleman' and still have your fleet up & running
                                                                with quality loads</p>
                                                        </div>
                                                    </div>
                                                    <div class="jet-animated-box__overlay"></div>
                                                </div>
                                                <div id="jet-animated-box__back-6ecfa968"
                                                    class="jet-animated-box__back">
                                                    <div class="jet-animated-box__inner">
                                                        <div
                                                            class="jet-animated-box__icon jet-animated-box__icon--back">
                                                            <div class="jet-animated-box-icon-inner"><span
                                                                    class="jet-elements-icon"><i aria-hidden="true"
                                                                        class="fasnc-icon-outline travel_hotel"></i></span>
                                                            </div>
                                                        </div>
                                                        <div class="jet-animated-box__content">
                                                            <h3
                                                                class="jet-animated-box__title jet-animated-box__title--back">
                                                                More info</h3>
                                                            <p
                                                                class="jet-animated-box__description jet-animated-box__description--back">
                                                                With independent dispatch services, cut the
                                                                'middleman' and still have your fleet up & running
                                                                with quality loads</p><a
                                                                class="elementor-button elementor-size-md jet-animated-box__button jet-animated-box__button--back jet-animated-box__button--icon-"
                                                                href="#"><span
                                                                    class="jet-animated-box__button-text">Learn
                                                                    More</span></a>

                                                        </div>
                                                    </div>
                                                    <div class="jet-animated-box__overlay"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-7c593b5d elementor-invisible"
                            data-id="7c593b5d" data-element_type="column"
                            data-settings="{&quot;animation&quot;:&quot;zoomIn&quot;,&quot;animation_delay&quot;:400}">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-6e22597c elementor-widget elementor-widget-jet-animated-box"
                                    data-id="6e22597c" data-element_type="widget"
                                    data-widget_type="jet-animated-box.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-jet-animated-box jet-elements">
                                            <div id="jet-animated-box-6e22597c"
                                                class="jet-animated-box jet-box-effect-10"
                                                data-settings='{"widgetId":"6e22597c","switchEventType":"hover","paperFoldDirection":"left","slideOutDirection":"left"}'>
                                                <div id="jet-animated-box__front-6e22597c"
                                                    class="jet-animated-box__front">
                                                    <div class="jet-animated-box__inner">
                                                        <div
                                                            class="jet-animated-box__icon jet-animated-box__icon--front">
                                                            <div class="jet-animated-box-icon-inner"><span
                                                                    class="jet-elements-icon"><i aria-hidden="true"
                                                                        class="fa fa-snowflake"></i></span></div>
                                                        </div>
                                                        <div class="jet-animated-box__content">
                                                            <h3
                                                                class="jet-animated-box__title jet-animated-box__title--front">
                                                                Reefer dispatch services</h3>
                                                            <p
                                                                class="jet-animated-box__description jet-animated-box__description--front">
                                                                Goods that require freezing or a maintained
                                                                temperature are transported inside reefer container.
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div class="jet-animated-box__overlay"></div>
                                                </div>
                                                <div id="jet-animated-box__back-6e22597c"
                                                    class="jet-animated-box__back">
                                                    <div class="jet-animated-box__inner">
                                                        <div
                                                            class="jet-animated-box__icon jet-animated-box__icon--back">
                                                            <div class="jet-animated-box-icon-inner"><span
                                                                    class="jet-elements-icon"><i aria-hidden="true"
                                                                        class="fasnc-icon-outline travel_hotel"></i></span>
                                                            </div>
                                                        </div>
                                                        <div class="jet-animated-box__content">
                                                            <h3
                                                                class="jet-animated-box__title jet-animated-box__title--back">
                                                                More info</h3>
                                                            <p
                                                                class="jet-animated-box__description jet-animated-box__description--back">
                                                                Goods that require freezing or a maintained
                                                                temperature are transported inside reefer container.
                                                            </p><a
                                                                class="elementor-button elementor-size-md jet-animated-box__button jet-animated-box__button--back jet-animated-box__button--icon-"
                                                                href="Reefer.php"><span
                                                                    class="jet-animated-box__button-text">Learn
                                                                    More</span></a>

                                                        </div>
                                                    </div>
                                                    <div class="jet-animated-box__overlay"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-3a8e09ae"
                            data-id="3a8e09ae" data-element_type="column">
                            <div class="elementor-widget-wrap">
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <footer class="footer bg-gold">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="footer__about">
                        <div class="footer__logo">
                            <a href="./index.php"><img src="./img/new_logo.png" alt=""></a>
                        </div>
                        <p>We’re a professional freight dispatching company with proven experience in
                            the
                            field.
                            Our team helps you get the most profitable loads to deliver. We generate
                            high
                            quality
                            and converting leads, providing you all the documents. Making business
                            efficient
                            for both parties.
                        </p>
                        <div class="footer__social">
                            <a href="#"><span class="social_facebook"></span></a>
                            <a href="#"><span class="social_twitter"></span></a>
                            <a href="#"><span class="social_linkedin"></span></a>
                            <a href="#"><span class="social_pinterest"></span></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 offset-lg-1 col-md-6 col-sm-6">
                    <div class="footer__widget">
                        <h5>Quick links</h5>
                        <ul>
                                <li><a href="./about.php">History</a></li>
                                <li><a href="./Dry-van.php">DRY VAN DISPATCH SERVICE</a></li>
                                <li><a href="./Owner-operator.php">OWNER OPERATOR SERVICE</a></li>
                                <li><a href="./Power-only.php">POWER ONLY DISPATCH SERVICE</a></li>
                                <li><a href="./Reefer.php">REEFER DISPATCH SERVICE</a></li>
                                <li><a href="./conditions.php">Terms & Conditions</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="footer__widget">
                        <h5>Contacts</h5>
                        <ul class="address">
                            <li><span class="icon_pin"></span><a href="https://goo.gl/maps/Xs7t8fcVACHGszMh8">978
                                    Hempstead
                                    Tpke,Franklin
                                    Sq,US</a></li>
                            <li><span class="icon_phone"></span><a href="tel:5554280940">
                                    +1-516-246-6566</a></li>
                            <li><span class="icon_mail"></span> <a href="mailto:Info@paramountservices.com"
                                    class="__cf_email__"
                                    data-cfemail="b3daddd5dc9dd0dcdfdcdfdad1f3d4ded2dadf9dd0dcde">Info@paramountservices.com</a>
                            </li>
                        </ul>


                    </div>
                </div>
            </div>
        </div>
        <div class="footer__copyright">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-8">
                        <div class="footer__copyright__text">

                            <p>Copyright &copy;
                                <script data-cfasync="false" src="#"></script>
                                <script>document.write(new Date().getFullYear());</script> All rights
                                reserved
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    

    <script type='text/javascript' src='./sources/slider-pro-min16.js' id='jsticky-js'></script>
    <script type='text/javascript' src='./sources/slider-pro-min17.js' id='elementor-webpack-runtime-js'></script>
    <script type='text/javascript' src='./sources/slider-pro-min18.js' id='elementor-frontend-modules-js'></script>
    <script type='text/javascript' src='./sources/slider-pro-min19.js' id='elementor-waypoints-js'></script>
    <script type='text/javascript' src='./sources/slider-pro-min21.js' id='swiper-js'></script>
    <script type='text/javascript' src='./sources/slider-pro-min22.js' id='share-link-js'></script>
    <script type='text/javascript' src='./sources/slider-pro-min23.js' id='elementor-dialog-js'></script>
    <script type='text/javascript' id='elementor-frontend-js-before'>
        var elementorFrontendConfig = { "environmentMode": { "edit": false, "wpPreview": false, "isScriptDebug": false }, "i18n": { "shareOnFacebook": "Share on Facebook", "shareOnTwitter": "Share on Twitter", "pinIt": "Pin it", "download": "Download", "downloadImage": "Download image", "fullscreen": "Fullscreen", "zoom": "Zoom", "share": "Share", "playVideo": "Play Video", "previous": "Previous", "next": "Next", "close": "Close" }, "is_rtl": false, "breakpoints": { "xs": 0, "sm": 480, "md": 768, "lg": 1025, "xl": 1440, "xxl": 1600 }, "responsive": { "breakpoints": { "mobile": { "label": "Mobile", "value": 767, "direction": "max", "is_enabled": true }, "mobile_extra": { "label": "Mobile Extra", "value": 880, "direction": "max", "is_enabled": false }, "tablet": { "label": "Tablet", "value": 1024, "direction": "max", "is_enabled": true }, "tablet_extra": { "label": "Tablet Extra", "value": 1365, "direction": "max", "is_enabled": false }, "laptop": { "label": "Laptop", "value": 1620, "direction": "max", "is_enabled": false }, "widescreen": { "label": "Widescreen", "value": 2400, "direction": "min", "is_enabled": false } } }, "version": "3.2.5", "is_static": false, "experimentalFeatures": { "e_dom_optimization": true, "a11y_improvements": true, "landing-pages": true }, "urls": { "assets": "https:\/\/www.statesdispatchservices.com\/wp-content\/plugins\/elementor\/assets\/" }, "settings": { "page": [], "editorPreferences": [] }, "kit": { "body_background_background": "classic", "active_breakpoints": ["viewport_mobile", "viewport_tablet"], "global_image_lightbox": "yes", "lightbox_enable_counter": "yes", "lightbox_enable_fullscreen": "yes", "lightbox_enable_zoom": "yes", "lightbox_enable_share": "yes", "lightbox_title_src": "title", "lightbox_description_src": "description" }, "post": { "id": 554, "title": "Services%20-%20States%20dispatch%20services", "excerpt": "", "featuredImage": false } };
    </script>
    <script type='text/javascript' src='./sources/slider-pro-min24.js' id='elementor-frontend-js'></script>
    <script type='text/javascript' id='jet-blocks-js-extra'>
        /* <![CDATA[ */
        var JetHamburgerPanelSettings = { "ajaxurl": "#", "isMobile": "false", "templateApiUrl": "#", "devMode": "false" };
            /* ]]> */
    </script>
    <script type='text/javascript' src='./sources/slider-pro-min25.js' id='jet-blocks-js'></script>
    <script type='text/javascript' id='jet-elements-js-extra'>
        /* <![CDATA[ */
        var jetElements = { "ajaxUrl": "#", "isMobile": "false", "templateApiUrl": "#", "devMode": "false", "messages": { "invalidMail": "Please specify a valid e-mail" } };
            /* ]]> */
    </script>
    <script type='text/javascript' src='./sources/slider-pro-min26.js' id='jet-elements-js'></script>
    <script type='text/javascript' src='./sources/slider-pro-min27.js' id='jet-menu-widgets-scripts-js'></script>
    <script type='text/javascript' id='jet-tabs-frontend-js-extra'>
        /* <![CDATA[ */
        var JetTabsSettings = { "ajaxurl": "#", "isMobile": "false", "templateApiUrl": "#", "devMode": "false" };
            /* ]]> */
    </script>

    
    
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

    <script async src="./sources/tagmanager.js"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');
       

    </script>
    <script defer src="./sources/cloudflare.js"></script>


</body>

</html>