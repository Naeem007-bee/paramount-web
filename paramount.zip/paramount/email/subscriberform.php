<?php
$to = 'innoxentmuaz22@gmail.com';
$subject = 'Proposal';
$message = $_POST['message']; 
$from = $_POST['email'];
 
// Sending email
mail($to, $subject, $message);
    

?>