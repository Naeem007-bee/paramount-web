<!DOCTYPE html>
<html lang="zxx">

<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <meta charset="UTF-8">
    <meta name="description" content="Freight-Broker Template">
    <meta name="keywords" content="Freight-Broker, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name='robots' content='index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1'>
    <meta property="og:locale" content="en_US" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Fracktech: Top-Notch Web Development Company" />
    <meta property="og:description"
        content="Fracktech is a web development company that designs and develops stunning web applications and responsive content for all types businesses." />
    <meta property="og:url" content="https://fracktechnologies.com/" />
    <meta property="og:site_name" content="Fracktech" />
    <meta property="article:modified_time" content="2021-07-12T07:37:07+00:00" />
    <title>Paramount-Dispatch | Thanks</title>
    <!---->
    <link href="./sources/fontsgoogle.css" rel="stylesheet">
    <link href="./sources/fontsgoogle2.css" rel="stylesheet">

    <link rel="stylesheet" href="./sources/bootstrap.css" type="text/css" />

    <link rel='stylesheet' id='google-fonts-1-css' href='./sources/gooleaps.css' type='text/css' media='all' />

</head>

<body>
    <header class="header">
        <div class="header__top">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 offset-lg-3">
                        <ul class="header__top__widget">
                            <li><span class="icon_phone"></span> +1-516-246-6566</li>
                            <li><span class="icon_pin"></span> 978 Hempstead Tpke, Franklin Sq, NY, US</li>
                        </ul>
                        <div class="header__top__right">
                            <div class="header__top__right__auth">
                                <a href="#"><span class="icon_profile"></span> Register or Sign in</a>
                            </div>
                            <div class="header__top__right__social">
                                <a href="#"><span class="social_facebook"></span></a>
                                <a href="#"><span class="social_twitter"></span></a>
                                <a href="#"><span class="social_linkedin"></span></a>
                                <a href="#"><span class="social_pinterest"></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header__options">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3">
                        <div class="header__logo">
                            <a href="./index.php"><img src="img/new_logo.png" alt="" data-pagespeed-url-hash="356418928"
                                    onload="pagespeed.CriticalImages.checkImageForCriticality(this);"></a>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <nav class="header__menu mobile-menu">
                            <ul>
                                <li><a href="./index.php">Home</a></li>
                                <li><a href="./services.php">Services</a> </li>
                                <li><a href="./about.php">About</a></li>

                                <li><a href="./Pricing.php">Pricing</a></li>
                                <li class="active"><a href="./Carrier.php">Carrier-Setup</a></li>
                                <li><a href="./Faq.php">FAQs</a></li>

                                <li><a href="./contact.php">Contacts</a></li>
                            </ul>
                        </nav>
                    </div>
                    
                    
                </div>
            </div>
        </div>
    </header><br><br>
    <div id="content" class="site-content " style="text-align: center;">
        <div data-elementor-type="wp-page" data-elementor-id="1864" class="elementor elementor-1864"
            data-elementor-settings="[]">
            <div class="elementor-section-wrap">
                <section
                    class="elementor-section elementor-top-section elementor-element elementor-element-d381451 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                    data-id="d381451" data-element_type="section">
                    <div class="elementor-container elementor-column-gap-default">
                        <div class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-e3fe5f3"
                            data-id="e3fe5f3" data-element_type="column">
                            <div class="elementor-widget-wrap elementor-element-populated">
                                <div class="elementor-element elementor-element-6151142 elementor-widget elementor-widget-heading"
                                    data-id="6151142" data-element_type="widget" data-widget_type="heading.default">
                                    <div class="elementor-widget-container">
                                        <h2 class="elementor-heading-title elementor-size-default">Thank You!</h2>
                                    </div>
                                </div>
                                <div class="elementor-element elementor-element-1a2b08a elementor-widget elementor-widget-contact-form-7"
                                    data-id="1a2b08a" data-element_type="widget"
                                    data-widget_type="contact-form-7.default">
                                    <div class="elementor-widget-container">
                                        <div class="elementor-contact-form-7 jet-elements">
                                            <div role="form" class="wpcf7" id="wpcf7-f1863-p1864-o1" lang="en-US"
                                                dir="ltr">
                                                <div class="screen-reader-response">
                                                    <p role="status" aria-live="polite" aria-atomic="true"></p>
                                                    <ul></ul>
                                                </div>
                                                <form action="/step-2-contact-form7/#wpcf7-f1863-p1864-o1" method="post"
                                                    class="wpcf7-form init" novalidate="novalidate" data-status="init">
                                                    <div style="display: none;">
                                                        <input type="hidden" name="_wpcf7" value="1863" />
                                                        <input type="hidden" name="_wpcf7_version" value="5.4.1" />
                                                        <input type="hidden" name="_wpcf7_locale" value="en_US" />
                                                        <input type="hidden" name="_wpcf7_unit_tag"
                                                            value="wpcf7-f1863-p1864-o1" />
                                                        <input type="hidden" name="_wpcf7_container_post"
                                                            value="1864" />
                                                        <input type="hidden" name="_wpcf7_posted_data_hash" value="" />
                                                    </div>
                                                    <p>Please fill out the form on the previous page.</p>
                                                    <div class="wpcf7-response-output" aria-hidden="true"></div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>

    </div><br><br><!-- #content -->
    <footer class="footer">

        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <div class="footer__about">
                        <div class="footer__logo">
                            <a href="./index.php"><img src="./img/new_logo.png" alt=""
                                    data-pagespeed-url-hash="2531560010"
                                    onload="pagespeed.CriticalImages.checkImageForCriticality(this);"></a>
                        </div>
                        <p>We’re a professional freight dispatching company with proven experience in the field.
                            Our team helps you get the most profitable loads to deliver. We generate high quality
                            and converting leads, providing you all the documents. Making business efficient for
                            both
                            parties.
                        </p>
                        <div class="footer__social">
                            <a href="#"><span class="social_facebook"></span></a>
                            <a href="#"><span class="social_twitter"></span></a>
                            <a href="#"><span class="social_linkedin"></span></a>
                            <a href="#"><span class="social_pinterest"></span></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 offset-lg-1 col-md-6 col-sm-6">
                    <div class="footer__widget">
                        <h5>Quick links</h5>
                        <ul>
                            <li><a href="./about.php">History</a></li>
                            <li><a href="./services-details.php">DRY VAN DISPATCH SERVICE</a></li>
                            <li><a href="./services-details.php">OWNER OPERATOR SERVICE</a></li>
                            <li><a href="./services-details.php">POWER ONLY DISPATCH SERVICE</a></li>
                            <li><a href="./services-details.php">REEFER DISPATCH SERVICE</a></li>
                            <li><a href="./conditions.php">Terms & Conditions</a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="footer__widget">
                        <h5>Contacts</h5>
                        <ul class="address">
                            <li><span class="icon_pin"></span><a href="https://goo.gl/maps/Xs7t8fcVACHGszMh8">978
                                    Hempstead Tpke,Franklin Sq,US</a></li>
                            <li><span class="icon_phone"></span><a href="tel:5554280940"> +1-516-246-6566</a></li>
                            <li><span class="icon_mail"></span> <a href="mailto:Info@paramountservices.com"
                                    class="__cf_email__"
                                    data-cfemail="b3daddd5dc9dd0dcdfdcdfdad1f3d4ded2dadf9dd0dcde">Info@paramountservices.com</a>
                            </li>
                        </ul>


                    </div>
                </div>
            </div>
        </div>
        <div class="footer__copyright">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-8">
                        <div class="footer__copyright__text">

                            <p>Copyright &copy;
                                <script data-cfasync="false" src="#"></script>
                                <script>document.write(new Date().getFullYear());</script> All rights reserved
                            </p>
                        </div>
                    </div>
                    <!----
                            <div class="col-lg-3 col-md-4">
                                <div class="footer__copyright__links">
                                    <a href="#">Client Login</a>
                                    <a href="#">Join Team</a>
                                </div>
                            </div>-->
                </div>
            </div>
        </div>
    </footer>
</body>

</html>